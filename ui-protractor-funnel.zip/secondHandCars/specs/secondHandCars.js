var navigation = require('../pageObjects/navigation.js');
var product = require('../pageObjects/product.js')


describe('Navigating', function () {
	it('Open browser, navigate to homepage', function () {
		console.log("Navigeren naar tweedehands pagina");
		browser.sleep(5000);
		navigation.get();
	});

	it('Accepting cookies', function () {
		console.log("Accepting cookies")
		navigation.acceptCookies();
	})
	it('Navigeren naar volledig aanbod', function () {
		console.log("Klikken op: 'Bekijk volledig aanbod")
		navigation.bekijkVolledigAanbod();
	});

	it('Getting car name', function () {
		console.log("Getting car name\n");
		product.getCarName();
	})

	it('Getting fuel type', function () {
		console.log("Getting fuel type");
		product.getFuelType();
	})

	it('Getting construction year', function () {
		console.log("Getting construction year");
		product.getConstructionYear();
	})

	it('Getting mileage', function () {
		console.log("Getting mileage");
		product.getMileage();
	})

	it('Getting transmission type', function () {
		console.log("Getting transmission type");
		product.getTransmission();

	})

	it('Clicking on first car', function () {
		console.log("Clicking on first car");
		product.clickOnFirstCar();

	})

	it('Getting car name on detail page', function () {
		console.log("Getting car name on detail page");
		browser.sleep(8000);
		product.getCarDetailName();
	})

	it('Getting fuel type on detail page', function () {
		console.log("Getting fuel type on detail page");
		product.getFuelDetail();
	})

	it('Getting construction year on detail page', function () {
		console.log("Getting construction year on detail page");
		product.getConstructionYearDetail();
	})

	it('Getting mileage on detail page', function () {
		console.log("Getting mileage on detail page");
		product.getMileageDetail();
	})

	it('Getting transmission type on detail page', function () {
		console.log("Getting transmission type on detail page");
		product.geTransmissionDetailPage();
	})


});
