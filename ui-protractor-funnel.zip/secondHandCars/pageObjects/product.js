var Product = function () {
    var firstCar = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/span[2]/span[1]"));
    var carName = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/div"));
    var carNameDetailPage = element(by.xpath("//h1[@id='model_title']"));
    var fuelType = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/span[1]/span[1]/span[2]"));
    var constructionYear = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/span[1]/span[2]/span[2]"));
    var kilometerStand = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/span[1]/span[3]/span[2]"));
    var transmissionType = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/span[1]/span[4]/span[2]"));
    var fuelDetailPage = element(by.xpath("/html/body/div[2]/div/aside/div[1]/section[1]/ul/li[1]/span[2]"));
    var constructionYearDetailPage = element(by.xpath("/html/body/div[2]/div/aside/div[1]/section[1]/ul/li[2]/span[2]"));
    var mileageDetailPage = element(by.xpath("/html/body/div[2]/div/aside/div[1]/section[1]/ul/li[3]/span[2]"));
    var transmissionDetailPage = element(by.xpath("/html/body/div[2]/div/aside/div[1]/section[1]/ul/li[4]/span[2]"));
    var CNGlobal = "";
    var FTGlobal = "";
    var CYGlobal = "";
    var MLGlobal = "";
    var TTGlobal = "";



    this.getCarName = function () {
        carName.getText().then(function (CN) {
            console.log("Carname: " + CN);
            CNGlobal = CN
            return CNGlobal;
        });

    }

    this.getFuelType = function () {
        fuelType.getText().then(function (FT) {
            console.log("Fuel type: " + FT);
            FTGlobal = FT
            return FTGlobal;
        })

    }

    this.getConstructionYear = function () {
        constructionYear.getText().then(function (CY) {
            console.log("Construction Year: " + CY);
            CYGlobal = CY
            return CYGlobal;
        })
    }

    this.getMileage = function () {
        kilometerStand.getText().then(function (ML) {
            console.log("Mileage: " + ML);
            MLGlobal = ML
            return MLGlobal;
        })
    }

    this.getTransmission = function () {
        transmissionType.getText().then(function (TT) {
            console.log("Transmission: " + TT);
            TTGlobal = TT
            return TTGlobal;
        })
    }

    this.clickOnFirstCar = function () {
        firstCar.click()
        browser.sleep(8000);
    }

    this.getCarDetailName = function () {
        browser.waitForAngularEnabled(false);
        carNameDetailPage.getText().then(function (CDP) {
            expect(CDP).toBe(CNGlobal)
            console.log("Car name on detail page: " + CDP)
            //expect(CN).toEqual(CDP);
        })

    }

    this.getFuelDetail = function () {
        fuelDetailPage.getText().then(function (FDP) {
            expect(FDP).toBe(FTGlobal)
            console.log("Fuel on detail page: " + FDP)
        })

    }

    this.getConstructionYearDetail = function () {
        constructionYearDetailPage.getText().then(function (CYD) {
            removeMonth = CYD.slice(5)
            expect(removeMonth).toBe(CYGlobal);
            console.log("Constrution year on detail page is: " + removeMonth)
        })
    }

    this.getMileageDetail = function () {
        mileageDetailPage.getText().then(function (MDP) {
            expect(MDP).toBe(MLGlobal);
            console.log("Mileage on detail page is: " + MDP)
        })
    }

    this.geTransmissionDetailPage = function () {
        transmissionDetailPage.getText().then(function (TDP) {
            expect(TDP).toBe(TTGlobal)
            console.log('Getting transmission type on detail page: ' + TDP)
        })
    }


}




module.exports = new Product(); 
