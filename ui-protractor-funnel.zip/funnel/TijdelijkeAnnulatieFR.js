var Common = require('./VABCommon/common.js');
var dateFunctions = require('./VABCommon/dateFunctions.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
describe("TijdelijkeAnnulatieFR: Tijdelijke reisverzekering: Annulatie", function () {
	var common = new Common();
	var URL = common.applicationURL;
	var EC = protractor.ExpectedConditions;
	var totalPersons = 2;
	var personPriceFormatted;

	it('TijdelijkeAnnulatieFR: Open browser & accepteer cookies', function () {
		console.log("TijdelijkeAnnulatieFR: Open browser & accepteer cookies");
		browser.get(URL + '/fr/assistance/assistance-voyage/assistance-voyage-temporaire/assurance-annulation');
		browser.sleep(2000);
		common.cookie.click();
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieFR: Valideer prijs', function () {
		console.log("TijdelijkeAnnulatieFR: Valideer prijs");
		var ele = element(by.className("vab__calculator__form__theHeading"));
		browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: HomePage of Tijdelijke reisbijstand");

		element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 0');
		});
	});

	it('TijdelijkeAnnulatieFR: Vul totale reissom in', function () {
		console.log("TijdelijkeAnnulatieFR: Vul totale reissom in");
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[2]/app-text-option/div/label/div[2]/app-text-input/div/div/input')).sendKeys(3000);
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[4]/div/label/div[2]/app-new-datepicker/div/input')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieFR: Vul start datum in', function () {
		console.log("TijdelijkeAnnulatieFR: Vul start datum in");
		startDate = dateFunctions.addTotalDays(1);
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[3]/div/label/div[2]/app-new-datepicker/div/input')).sendKeys(startDate);

		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[4]/div/label/div[2]/app-new-datepicker/div/input')).click();
		browser.sleep(2000);
	});

	it
	it('TijdelijkeAnnulatieFR: Vul eind datum in', function () {
		console.log("TijdelijkeAnnulatieFR: Vul eind datum in");
		endDate = dateFunctions.addTotalDaysReferenceDate(startDate, 8);
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[4]/div/label/div[2]/app-new-datepicker/div/input')).sendKeys(endDate);

		// Wijzig focus door validaties
		element(by.className('vab__calculator__form__theHeading')).click();
		browser.sleep(2000);
	});


	it('TijdelijkeAnnulatieFR: Voeg personen', function () {
		console.log("TijdelijkeAnnulatieFR: Voeg personen toe");
		var personPrice = 150;
		var addPricePerson = 0;

		for (i = 0; i < totalPersons; i++) {
			element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[1]/app-stepper-option/div/label/div[2]/app-plus-minus-input/div/div[3]/span')).click();
			browser.sleep(2000);

			element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
				console.log('TijdelijkeAnnulatieFR: Valideer prijs');
				personPrice = personPrice + addPricePerson;
				personPriceFormatted = personPrice.toString().replace(".", ",");
				expect(defaultPricing).toBe('€ ' + personPriceFormatted);

				console.log('TijdelijkeAnnulatieFR: Persoon prijs = ' + personPrice);
				browser.sleep(2000);
			});
		}
	});

	it('TijdelijkeAnnulatieFR: Valideer prijs ', function () {
		console.log("TijdelijkeAnnulatieFR: Valideer prijs");
		browser.sleep(2000);
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ ' + personPriceFormatted);
		});
		browser.sleep(5000);

	});

	it('TijdelijkeAnnulatieFR: Klik op volgende knop', function () {
		console.log("TijdelijkeAnnulatieFR: Klik op volgende knop");
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/a/span')).click();
		browser.sleep(4000);
	});

	it('TijdelijkeAnnulatieFR: Valideer prijs', function () {
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).getText().then(function (price) {
			expect(price).toBe('€ ' + personPriceFormatted)
		});
	});


	it("TijdelijkeAnnulatieFR: Valideer start datum", function () {
		console.log("TijdelijkeAnnulatieFR: Valideer start datum: " + startDate);
		var inputStartDatum = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[1]/li/div[2]/div/app-contract-option/div/div/div/div[1]/div[1]/div/label/app-new-datepicker/div/input'));
		expect(inputStartDatum.getAttribute('value')).toEqual(startDate);
	});

	it("TijdelijkeAnnulatieFR: Valideer eind datum", function () {
		console.log("TijdelijkeAnnulatieFR: Valideer eind datum: " + endDate);
		var inputEindDatum = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[1]/li/div[2]/div/app-contract-option/div/div/div/div[1]/div[2]/div/label/app-new-datepicker/div/input'));
		expect(inputEindDatum.getAttribute('value')).toEqual(endDate);
	});

	it('TijdelijkeAnnulatieFR: Valideer nieuwe pagina 1/4', function () {
		console.log("TijdelijkeAnnulatieFR: Valideer nieuwe pagina 1/4");
		var ele = element(by.className("vab__calculator__form__price"));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 1 van 4: Jouw Tijdelijke annulatieverzekering");

		element(by.className('h1 vab__fs--2 vab__ff--special-1')).getText().then(function (defaultTitle) {
			expect(defaultTitle).toBe('Étape 1 sur 4 : Votre Assurance Annulation VAB');
		});
	});

	it('TijdelijkeAnnulatieFR: Vul gegevens personen in', function () {
		console.log("TijdelijkeAnnulatieFR: Vul gegevens personen in");
		for (i = 1; i < 4; i++) {
			console.log("TijdelijkeAnnulatieFR: Vul gegevens in persoon", +i + " in");
			element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[' + i + ']/div/div/label[1]/input')).sendKeys(common.userFirstName);
			element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[' + i + ']/div/div/label[2]/input')).sendKeys(common.userLastName);
			element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[' + i + ']/div/div/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);

			// Wijzig focus door validaties
			element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[1]/div/div/label[1]/input')).click();
			browser.sleep(2000);
		}
	});

	it('TijdelijkeAnnulatieFR: Voeg medereiziger toe', function () {
		console.log("TijdelijkeAnnulatieFR: Voeg medereiziger toe");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[2]/a/div')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieFR: Vul gegevens persoon 3 in', function () {
		console.log("TijdelijkeAnnulatieFR: Vul gegevens persoon 3 in");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[4]/div/div/label[1]/input')).sendKeys(common.userFirstName + "3");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[4]/div/div/label[2]/input')).sendKeys(common.userLastName + "3");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[4]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);
		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[2]/div/div/label[1]/input')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieFR: Valideer prijs', function () {
		console.log("TijdelijkeAnnulatieFR: Valideer prijs");
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ ' + personPriceFormatted);
			browser.sleep(2000);
		});
	});

	it('TijdelijkeAnnulatieFR: Klik op volgende knop', function () {
		console.log("TijdelijkeAnnulatieFR: Klik op volgende knop");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/div[1]/a/span')).click();
        browser.sleep(5000);        
		browser.waitForAngularEnabled(false);
	});

	it('TijdelijkeAnnulatieFR: Valideer nieuwe pagina 2/4', function () {
		console.log("TijdelijkeAnnulatieFR: Valideer nieuwe pagina 2/4");
		var ele = element(by.className("vab__calculator__form__price"));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 2 van 4:");
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ ' + personPriceFormatted);
		});
	});

	it('TijdelijkeAnnulatieFR: Vul adres in', function () {
		console.log("TijdelijkeAnnulatieFR: Vul adres in");
		common.zipcode.sendKeys(common.userZipcode);
		common.city.sendKeys(common.userCity);
		common.street.sendKeys(common.userStreet);
		common.houseNumber.sendKeys(common.userHouseNumber);

	});

	it('TijdelijkeAnnulatieFR: Vul email in', function () {
		console.log("TijdelijkeAnnulatieFR: Vul email in");
		common.email.sendKeys(common.userEmail);
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieFR: Klik checkbox algemene voorwaarden', function () {
		console.log("TijdelijkeAnnulatieFR: Klik checkbox algemene voorwaarden");
		common.checkboxGeneralTerms.click();
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieFR: Klik op volgende knop', function () {
		console.log("TijdelijkeAnnulatieFR: Klik op volgende knop");
		common.nextButton.click();
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieFR: Valideer nieuwe pagina 3/4', function () {
		console.log("TijdelijkeAnnulatieFR: Valideer nieuwe pagina 3/4");
		var ele = element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[1]/span[2]'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 3 van 4: Behoefteanalyse");

		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ ' + personPriceFormatted);
		});
	});

	it('TijdelijkeAnnulatieFR: Vul behoefteanalyse pagina in', function () {
		console.log("TijdelijkeAnnulatieFR: Vul behoefteanalyse pagina in");
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[3]/label[1]/span[2]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[4]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[5]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[1]/span[2]')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieFR: Klik op toon resultaat', function () {
		console.log("TijdelijkeAnnulatieFR: Klik op toon resultaat");
		element(by.id('submitBtn')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieFR: Valideer resultaat tekst', function () {
		console.log("TijdelijkeAnnulatieFR: Valideer resultaat tekst");
		element(by.xpath('//*[@id="scrollToHere"]/p[1]')).getText().then(function (text) {
			expect(text).toBe("Sur base de vos réponses, nous vous recommandons le produit suivant : Formule vacances avec bagages temporaire seul");
		});
		browser.sleep(2000);
	});

	it('TijdelijkeAnnulatieFR: Klik op volgende knop', function () {
		console.log("TijdelijkeAnnulatieFR: Klik op volgende knop");
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[8]/a[2]/span')).click();
		browser.sleep(4000);

	});

	it('TijdelijkeAnnulatieFR: Valideer nieuwe pagina', function () {
		console.log('TijdelijkeAnnulatieFR: Valideer nieuwe pagina');
		var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 40000, "Timeout of VisibilityOf: Stap 4 van 4");
	});

	if (common.applicationURL === 'https://acc.vab.be') {
		it('TijdelijkeAnnulatieFR: Betaalstap selecteer MasterCard', function () {
			paymentFunctions.masterCardPayment();
		});
	};
});


