var Common = require('./VABCommon/common.js');
var dateFunctions = require('./VABCommon/dateFunctions.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');

describe("TijdelijkeReisbijstandNL", function () {
    var common = new Common();
    var URL = common.applicationURL;
    var EC = protractor.ExpectedConditions;
    var totalPersons = 3;
    var totalVehiclesToAdd = 2;


    it('TijdelijkeReisbijstandNL: Open browser & accepteer cookies', function () {
        console.log("TijdelijkeReisbijstandNL: Open browser & accepteer cookies");
        browser.waitForAngularEnabled(false);
        browser.get(URL + '/nl/pech-en-reisbijstand/bijstand-op-reis/tijdelijke-reisbijstand');

        browser.wait(EC.visibilityOf(common.cookie), 30000, "Timeout of VisibilityOf: Bijstand auto en motor");
        common.cookie.click();
        browser.waitForAngularEnabled(false);

    });

    it("TijdelijkeReisbijstandNL:click bestel nu", function () {
        console.log("TijdelijkeReisbijstandNL: click bestel nu");
        element(by.xpath('/html/body/section[6]/div/ul/li[1]/ul/li[1]/div/div[4]/a')).click();

    });

    it("TijdelijkeReisbijstandNL: Wacht op pagina tijdelijke reisbijstand", function () {
        console.log("TijdelijkeReisbijstandNL: Wacht op pagina reisbijstand");
        var ele = element(by.className("vab__intro__title vab__heading--2 ng-star-inserted"));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: HomePage of Tijdelijke reisbijstand");
    })

    it("TijdelijkeReisbijstandNL: Scroll naar calculator", function () {
        console.log("TijdelijkeReisbijstandNL: Scrollen naar calculator");
        var elementToScrollTo = element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/p/span'));
        browser.actions().mouseMove(elementToScrollTo).perform();
        browser.sleep(2000);
    });

    it("TijdelijkeReisbijstandNL: Valideer prijs", function () {
        console.log("TijdelijkeReisbijstandNL: Valideer prijs");
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPrice) {
            expect(defaultPrice).toBe('€ 0');
        });
    });

    it("TijdelijkeReisbijstandNL: Vul begindatum  reis in", function () {
        console.log("TijdelijkeReisbijstandNL: Invullen datum begin reis: ");
        startDate = dateFunctions.addTotalDays(1);;
        console.log('startdate: ' + startDate);
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[2]/div/label/div[2]/app-new-datepicker/div[1]/input')).sendKeys(startDate);
        browser.sleep(8000);
        //Wijzig focus door validatie
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[1]/div/h2')).click();
        browser.sleep(4000);
    });


    it("TijdelijkeReisbijstandNL: Vul eind datum reis in", function () {
        console.log("TijdelijkeReisbijstandNL: Invullen datum einde reis: ");
        endDate = dateFunctions.addTotalDays(8);
        console.log('enddate: ' + endDate);
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[3]/div/label/div[2]/app-new-datepicker/div/input')).sendKeys(endDate);
        browser.sleep(8000);

        //Wijzig focus door validatie
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/p')).click();
        browser.sleep(2000);

    });

    it("TijdelijkeReisbijstandNL: Valideer prijs", function () {
        console.log("TijdelijkeReisbijstandNL: Valideer prijs");
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (priceAfterDate) {
            expect(priceAfterDate).toBe('€ 25');
        });
    });

    it('TijdelijkeReisbijstandNL: Voeg personen', function () {
        console.log("TijdelijkeReisbijstandNL: Voeg personen toe");
        var personPrice = 25;
        var addPricePerson = 25;

        for (i = 0; i < 2; i++) {
            element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[1]/app-stepper-option/div/label/div[2]/app-plus-minus-input/div/div[3]/span')).click();
            browser.sleep(2000);

            element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
                console.log('TijdelijkeReisbijstandNL: Valideer prijs');
                personPrice = personPrice + addPricePerson;
                var personPriceFormatted = personPrice.toString().replace(".", ",");
                expect(defaultPricing).toBe('€ ' + personPriceFormatted);

                console.log('TijdelijkeReisbijstandNL: Persoon prijs = ' + personPrice);
            });
        }
    });

    it("TijdelijkeReissbijstandNL: Voeg voertuigen toe", function () {
        console.log("TijdelijkeReisbijstandNL: Voeg voertuig toe");
        var vehiclePrice = 75;
        var addPriceVehicle = 31.2;
        for (i = 0; i < 2; i++) {
            element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
            browser.sleep(2000);

            element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (priceAfterVehicles) {
                console.log("TijdelijkeReisbijstandNL: Valideer prijs" + priceAfterVehicles);
                vehiclePrice = vehiclePrice + addPriceVehicle;
                var vehiclePriceFormatted = vehiclePrice.toString().replace(".", ",");
                expect(priceAfterVehicles).toBe('€ ' + vehiclePriceFormatted);

                console.log('TijdelijkeReisbijstandNL: Voertuig prijs = ' + vehiclePrice);
            });
        }
    });

    it("TijdelijkeReisbijstandNL: Klik op bestel nu", function () {
        console.log("TijdelijkeReisbijstandNL: Klik op bestel nu");
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/div/a')).click();
        browser.sleep(5000);
    });



    it("TijdelijkeReisbijstandNL: Valideer prijs", function () {
        console.log("TijdelijkeReisbijstandNL: Valideer prijs");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).getText().then(function (priceOnSecondPage) {
            expect(priceOnSecondPage).toBe('€ 137,4');
        });

    });

    it("TijdelijkeReisbijstandNL: Valideer start datum", function() {
        console.log("TijdelijkeReisbijstandNL: Valideer start datum");
        var inputStartDatum = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[1]/li/div[2]/div/app-contract-option/div/div/div/div[1]/div[1]/div/label/app-new-datepicker/div/input'));
        // gebruik getAttribute('value') ipv van getText(), omdat het een input field is.
        expect(inputStartDatum.getAttribute('value')).toEqual(startDate);
    });

    it("TijdelijkeReisbijstandNL: Valideer eind datum", function() {
        console.log("TijdelijkeReisbijstandNL: Valideer eind datum");
        var inputEindDatum = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[1]/li/div[2]/div/app-contract-option/div/div/div/div[1]/div[2]/div/label/app-new-datepicker/div/input'));
        // gebruik getAttribute('value') ipv van getText(), omdat het een input field is.
        expect(inputEindDatum.getAttribute('value')).toEqual(endDate);
    });


    it('TijdelijkeVakantiePakketNL: Vul gegevens in personen in', function () {

		for (i = 1; i <= totalPersons; i++) {
		console.log("TijdelijkeVakantiePakketNL: Vul gegevens in persoon", +i+ " in");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person['+i+']/div/div/label[1]/input')).sendKeys(common.userFirstName);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person['+i+']/div/div/label[2]/input')).sendKeys(common.userLastName);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person['+i+']/div/div/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);

		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[1]/div/div/label[1]/input')).click();
		browser.sleep(2000);

		}
    });
    
    it("TijdelijkeReisbijstandNL: Wijzig focus door validatie", function () {
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
        browser.sleep(2000);
    });

    it("TijdelijkeReisbijstandNL: Valideer prijs", function() {
        console.log("TijdelijkeReisbijstandNL: Valideer prijs");
          element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).getText().then(function (priceOnSecondPage) {
            expect(priceOnSecondPage).toBe('€ 137,4');
        });
    });

    it('TijdelijkeReisbijstandNL: vul nummerplaten in', function(){

        for (i = 1; i <= totalVehiclesToAdd; i++) {

            console.log("TijdelijkeReisbisjtandNL: Vul nummerplaat", +i+ " in");
            let rdnNummerplaat = Math.random().toString(36).substr(2, 6);
            element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[4]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle['+i+']/div/div/label/input')).sendKeys("1"+rdnNummerplaat);
            // Wijzig focus door validaties
            element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[2]/div/div/label[1]/input')).click();
            browser.sleep(2000);

        }
    });

    it("TijdelijkeReisbijstandNL: Wijzig focus door validatie", function () {
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
        browser.sleep(2000);
    });

    it("TijdelijkeReisbijstandNL: Voeg voertuig toe", function () {
        console.log("TijdelijkeReisbijstandNL: Voeg voertuig toe");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[4]/li/div[2]/div/app-vehicles-option/div[2]/a')).click();
        browser.sleep(1000);
    });

    it("TijdelijkeReisbisjtandNL: Vul nummerplaat in", function () {
        console.log("TijdelijkeReisbijstandNL: Vul nummerplaat in");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[4]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[3]/div/div/label/input')).sendKeys("1IP-895");
    });

    it("TijdelijkeReisbijstandNL: Wijzig focus door validatie", function () {
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
        browser.sleep(2000);
    });

    it("TijdelijkeReisbijstandNL: Valideer prijs", function () {
        console.log("TijdelijkeReisbijstandNL: Valideer prijs");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).getText().then(function (priceOnSecondPage) {
            expect(priceOnSecondPage).toBe('€ 168,6');
        });
    });

    it("TijdelijkeReisbijstandNL: Klikken op volgende knop", function () {
        console.log("TijdelijkeReisbijstandNL: Klikken op volgende knop");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/div[1]/a')).click();
        browser.sleep(3000);
    });

    it("TijdelijkeReisbijstandNL: Vul contactgegevens in:", function () {
        console.log("TijdelijkeReisbijstandNL: Vul contactgegevens in");
        common.zipcode.sendKeys(common.userZipcode);
        browser.sleep(2000);

        common.city.sendKeys(common.userCity);
        browser.sleep(2000);

        common.street.sendKeys(common.userStreet);
        browser.sleep(2000);

        common.houseNumber.sendKeys(common.userHouseNumber);
        browser.sleep(2000);

        common.email.sendKeys(common.userEmail);
        browser.sleep(2000);
    });

    it("TijdelijkeReisbijstandNL: Bevestig correcte gegevens", function () {
        console.log("TijdelijkeReisbijstandNL: Bevestig correcte gegevens");
        element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/label/span[1]')).click();
    });

    it("TijdelijkeReisbijstandNL: Klik op volgende knop", function () {
        console.log("TijdelijkeReisbijstandNL: Klik op volgende knop");
        element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/div[2]/button[2]')).click();
        browser.sleep(3000);
    });

    it("TijdelijekReisbijstandNL: Vul behoefteanalyse in", function () {
        console.log("TijdelijkeReisbijstandNL: Vul behoefteanalyse in");
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[3]/label[1]/span[1]')).click();
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[4]/label[1]/span[1]')).click();
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[5]/label[2]/span[1]')).click();
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[2]/span[1]')).click();
    });

    it("TijdelijkeReisbisjtandNL: Klikken op toon resultaat", function () {
        console.log("TijdelijkeReisbijstandNL: Klikken op toon resultaat");
        element(by.id('submitBtn')).click();
        browser.sleep(3000);
    });

    it("TijdelijkeReisbijstandNL: Klik op volgende knop", function () {
        console.log("TijdelijkeReisbijstandNL: Klik op volgende knop");
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[8]/a[2]')).click();
        browser.sleep(3000);
    });

    it("TijdelijkeReisbijstandNL: Valideer prijs", function () {
        console.log("TijdelijkeReisbijstandNL: Valideer prijs");
        element(by.xpath('//*[@id="funnelStep2Calc"]/div/div[3]/span')).getText().then(function (priceOnSecondPage) {
            expect(priceOnSecondPage).toBe('€ 168,6');
        });
    });

    it('TijdelijkeReisbijstandNL: Valideer nieuwe pagina', function () {
		console.log('TijdelijkeReisbijstandNL: Valideer nieuwe pagina');
		var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 4 van 4");
	});

    if (common.applicationURL === 'https://acc.vab.be') {
        it('TijdelijkeReisbijstandNL: Selecteer CBC', function () {
            paymentFunctions.cbcPayment();
        });
    };
});