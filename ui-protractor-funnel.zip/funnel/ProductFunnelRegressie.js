var jasmineReporters = require('jasmine-reporters');
var reportsDirectory = 'funnel/reports/xml';

exports.config = {
  framework: 'jasmine',
  seleniumAddress: 'http://localhost:4444/wd/hub',
  //directConnect:true,
  getPageTimeout: 500000,
  jasmineNodeOpts: {
    defaultTimeoutInterval: 200000
  },
  capabilities: {
    browserName: 'chrome',
    shardTestFiles: true,
    maxInstances: 1
  },
  params: { 
    environment: "acc",
    // Activeer accept all cookies: element(by.xpath('//*[@id="CybotCookiebotDialogBodyButtonAccept"]')),
    cookie: '//*[@id="CybotCookiebotDialogBodyButtonDecline"]'
  },
  specs: [
    'FietsverzekeringNL.js',              // #0
    'ReisbijstandSingleNL.js',            // #1
    'PechbijstandNL.js',                  // #2
    'MotorbijstandJaarNL.js',             // #3
    'FietsbijstandSingleNL.js',           // #4
    'AnnulatieverzekeringSingleNL.js',    // #5
    'BijstandspakketSingleNL.js',         // #6
    'VakantiepakketSingleNL.js',          // #7
    'VakantiepakketGezinFR.js',           // #8
    'MultipakketSingleNL.js',             // #9
    'MultipakketGezinFR.js',              // #10
    'FietsverzekeringFR.js',              // #11
    'MotorbijstandSeizoenFR.js',          // #12
    'PechbijstandFR.js',                  // #13
    'FietsbijstandDuoFR.js',              // #14
    'ReisbijstandGezinFR.js',             // #15
    'AnnulatieverzekeringGezinFR.js',     // #16
    'BijstandspakketGezinFR.js',          // #17
    'TijdelijkeBagageNL.js',              // #18
    'TijdelijkeBagageFR.js',              // #19
    'TijdelijkeAnnulatieNL.js',           // #20
    'TijdelijkeReisbijstandNL.js',        // #21
    'TijdelijkeReisbijstandFR.js',        // #22
    'TijdelijkeAnnulatieFR.js',           // #23
    'TijdelijkeVakantiepakketNL.js',      // #24
    'TijdelijkeReisbijstandNL.js',        // #25
    'TijdelijkeReisbijstandFR.js',        // #26
    'TijdelijkeVakantiepakketFR.js',      // #27
    'TijdelijkeVakantiepakketFR.js'       // #28 
  ],
  exclude: [
    'TijdelijkeReisbijstandBagageNL.js',     // #29
    'TijdelijkeReisbijstandBagageFR.js',     // #30   
  ],
  onPrepare: function () {
    //Maximize
    browser.driver.manage().window().maximize();

    //xml report generated for Azure DevOps
    jasmine.getEnv().addReporter(new jasmineReporters.JUnitXmlReporter({
      consolidateAll: false,
      savePath: reportsDirectory,
      filePrefix: 'xmlOutput'
    }));
  }
};

/*

browserNames:
* MicrosoftEdge : https://stackoverflow.com/questions/47891742/how-to-configure-protractor-js-for-running-tests-in-microsoft-edge
* chrome
* firefox
* safari
* internet explorer

Don't forget to install all drivers for the correct versions
Don't forget firefox brings issues for compatibility, they made some changes so you'll have to use firefox version 47 and not higher. (or use heavy workarounds)


*/