var Common = require('./VABcommon/common.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
describe("Buy a product: AnnulatieverzekeringGezinFR", function () {
    var common = new Common();
    var applicationURL = common.applicationURL;
    var EC = protractor.ExpectedConditions;

    it('AnnulatieverzekeringGezinFR: AnnulatieverzekeringGezinFR: Open browser & accepteer cookies', function () {
        console.log('AnnulatieverzekeringGezinFR: AnnulatieverzekeringGezinFR: Open browser & accepteer cookies');
        browser.get(applicationURL + '/fr/assistance/assistance-voyage/assurance-annulation');
        common.cookie.click();
        browser.sleep(1000);
        browser.waitForAngularEnabled(false);
    });

    it('AnnulatieverzekeringGezinFR: Valideer titel calculator', function () {
        console.log('AnnulatieverzekeringGezinFR: Valideer titel calculator');
        var ele = element(by.className("vab__calculator__form__theHeading"));
        browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: HomePage Annulatieverzekering");

        element(by.className('vab__calculator__form__theHeading')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe(common.berekenPrijsTitelFR);
        });
    });

    it('AnnulatieverzekeringGezinFR: Valideer prijs calculator', function () {
        console.log('AnnulatieverzekeringGezinFR: Valideer prijs calculator');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 152');
        });
    });

    it('AnnulatieverzekeringGezinFR: Klik op checkbox Gezin', function () {
        console.log('AnnulatieverzekeringGezinFR: Klik op checkbox Gezin');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div/div/div/div[2]/div/div/label/span[2]')).click()
        browser.sleep(2000);
    });

    it('AnnulatieverzekeringGezinFR: Valideer prijs', function () {
        console.log('AnnulatieverzekeringGezinFR: Valideer prijs');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 230');
        });
    });

    it('AnnulatieverzekeringGezinFR: Klik op volgende knop', function () {
        console.log('AnnulatieverzekeringGezinFR: Klik op volgende knop');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/div/a')).click();
    });

    it('AnnulatieverzekeringGezinFR: Valideer nieuwe pagina 1/4', function () {
        console.log('AnnulatieverzekeringGezinFR: Valideer nieuwe pagina 1/4');
        var ele = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[1]/div[1]/h1'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 1 van 4: Jouw VAB-Annulatieverzekering");

        element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 230');
        });
    });

    it('AnnulatieverzekeringGezinFR: Vul gegevens in van persoon 1', function () {
        console.log('AnnulatieverzekeringGezinFR: Vul gegevens in van persoon 1');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[1]/div/div/label[1]/input')).sendKeys(common.userFirstName);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[1]/div/div/label[2]/input')).sendKeys(common.userLastName);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[1]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);

        // Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
        browser.sleep(2000);
    });

    it('AnnulatieverzekeringGezinFR: Vul detail gegevens in van persoon 2', function () {
        console.log("AnnulatieverzekeringGezinFR: Vul detail gegevens in van persoon 2");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[2]/div/div/label[1]/input')).sendKeys(common.userFirstName + "2");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[2]/div/div/label[2]/input')).sendKeys(common.userLastName + "2");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[2]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);

        // Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
        browser.sleep(2000);
    });


    it('AnnulatieverzekeringGezinFR: Bevestig correcte gegevens', function () {
        console.log("Bevestig correcte gegevens");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/label/span[1]')).click();
    })

    it('AnnulatieverzekeringGezinFR: Klik op volgende knop', function () {
        console.log("AnnulatieverzekeringGezinFR: Klik op volgende knop");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[4]/div[1]/a')).click();
    });

    it('AnnulatieverzekeringGezinFR: Valideer prijs', function () {
        console.log("AnnulatieverzekeringGezinFR: Valideer prijs");
        var ele = element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/label[2]/span[2]'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 2 van 4: Gegevens");

        element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 230');
        });
    });

    it('AnnulatieverzekeringGezinFR: Vul adres in', function () {
        console.log("AnnulatieverzekeringGezinFR: Vul adres in");
        common.zipcode.sendKeys(common.userZipcode);
        common.city.sendKeys(common.userCity);
        common.street.sendKeys(common.userStreet);
        common.houseNumber.sendKeys(common.userHouseNumber);
    });

    it('AnnulatieverzekeringGezinFR: Vul email in', function () {
        console.log("AnnulatieverzekeringGezinFR: Vul email in");
        common.email.sendKeys(common.userEmail);
        browser.sleep(2000);
    });

    it('AnnulatieverzekeringGezinFR: Klik op checkbox', function () {
        console.log("AnnulatieverzekeringGezinFR: Klik op checkbox");
        common.checkboxGeneralTerms.click();
        browser.sleep(2000);
    });

    it('AnnulatieverzekeringGezinFR: Klik op volgende knop', function () {
        console.log("AnnulatieverzekeringGezinFR: Klik op volgende knop");
        common.nextButton.click();
    });

    it('AnnulatieverzekeringGezinFR: Valideer nieuwe pagina 3/4', function () {
        console.log("AnnulatieverzekeringGezinFR: Valideer nieuwe pagina 3/4");
        var ele = element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[1]/span[2]'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 3 van 4: Behoefteanalyse");

        element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 230');
            browser.sleep(2000);
        });
    });

    it('AnnulatieverzekeringGezinFR: Vul de behoefteanalyse in', function () {
        console.log("AnnulatieverzekeringGezinFR: Vul de behoefteanalyse in");
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[3]/label[1]/span[2]')).click();
        browser.sleep(2000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[4]/label[1]/span[1]')).click();
        browser.sleep(2000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[5]/label[1]/span[2]')).click();
        browser.sleep(2000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[1]/span[2]')).click();
        browser.sleep(2000);
    });

    it('AnnulatieverzekeringGezinFR: Klik op show results knop', function () {
        console.log("AnnulatieverzekeringGezinFR: Klik op show results knop");
        element(by.id('submitBtn')).click();
        browser.sleep(4000);
    });

    it('AnnulatieverzekeringGezinFR: Klik op volgende knop', function () {
        console.log("AnnulatieverzekeringGezinFR: Klik op volgende knop");

        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[8]/a[2]/i')).click();
        browser.sleep(5000);
    });

    it('AnnulatieverzekeringGezinFR: Valideer nieuwe pagina 4/4', function () {
        console.log("AnnulatieverzekeringGezinFR: Valideer nieuwe pagina 4/4");
        element(by.className("vab__fs--2 vab__ff--special-1")).getText().then(function (text) {
            expect(text).toBe('Étape 4 sur 4 : Paiement');
            browser.sleep(3000);
        });
    });

    it('AnnulatieverzekeringGezinFR: Valideer prijs', function () {
        console.log("AnnulatieverzekeringGezinFR: Valideer prijs ");
        element(by.className("vab__calculator__form__price")).getText().then(function (text) {
            expect(text).toBe('€ 230');
        });
    });

    if (common.payment) {
        it('AnnulatieverzekeringSingleNL: Betaalstap', function () {
            paymentFunctions.kbcPayment();
        });
    };
});
