var Common = require('./VABCommon/common.js');
var dateFunctions = require('./VABCommon/dateFunctions.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
describe("VakantiepakketGezinFR: Buy a product: Vakantiepakket Gezin", function () {
	console.log('VakantiepakketGezinFR: start testen VakantiepakketGezinFR');
	var common = new Common();
	var applicationURL = common.applicationURL;
	var EC = protractor.ExpectedConditions;

	it('VakantiepakketGezinFR: Open browser & accepteer cookies', function () {
		console.log('VakantiepakketGezinFR: Open browser & accepteer cookies');
		browser.get(applicationURL + '/fr/assistance/assistance-voyage/formule-vacances');
		browser.sleep(2000);
		browser.wait(EC.visibilityOf(common.cookie), 50000, "Wait for cookie accept");
		common.cookie.click();
		browser.sleep(2000);
	});

	it('VakantiepakketGezinFR: Valideer prijs', function () {
		console.log('VakantiepakketGezinFR: Valideer prijs');
		var ele = element(by.className("vab__calculator__form__theHeading"));
		browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: HomePage Vakantiepakket");

		element(by.className('vab__calculator__form__theHeading')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe(common.berekenPrijsTitelFR);
		});

		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 213');
		});
	});

	it('VakantiepakketGezinFR: Selecteer gezin', function () {
		console.log('VakantiepakketGezinFR: Selecteer gezin');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div/div/div/div[2]/div/div/label/span[1]')).click();
		browser.sleep(2000);
	});


	it('VakantiepakketGezinFR: Valideer prijs', function () {
		console.log('VakantiepakketGezinFR: Valideer prijs');
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 300');
		});
	});

	it('VakantiepakketGezinFR: Voeg extra voertuig toe', function () {
		console.log('VakantiepakketGezinFR: Voeg extra voertuig toe');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[1]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);

		console.log('VakantiepakketGezinFR: Valideer prijs');
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 317');
		});
	});

	it('VakantiepakketGezinFR: Voeg vervangwagen buitenland toe', function () {
		console.log('VakantiepakketGezinFR: Voeg vervangwagen buitenland toe');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[2]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);

		console.log('VakantiepakketGezinFR: Valideer prijs');
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 353');
		});
	});

	it('VakantiepakketGezinFR: Voeg extra voertuig toe', function () {
		console.log('VakantiepakketGezinFR: Voeg extra voertuig toe');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[1]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);

		console.log('VakantiepakketGezinFR: Valideer prijs');
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 370');
		});
	});

	it('VakantiepakketGezinFR: Voeg vervangwagen buitenland toe', function () {
		console.log('VakantiepakketGezinFR: Voeg vervangwagen buitenland toe');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[2]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);

		console.log('VakantiepakketGezinFR: Valideer prijs');
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 406');
		});
	});

	it('VakantiepakketGezinFR: Optie motorhome', function () {
		console.log('VakantiepakketGezinFR: Optie motorhome');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[3]/div/label/div/div/span')).click();
		browser.sleep(2000);

		console.log('VakantiepakketGezinFR: Valideer prijs');
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 471');
		});
	});

	it('VakantiepakketGezinFR: Optie bagage', function () {
		console.log('VakantiepakketGezinFR: Optie bagage');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[5]/div/label/div/div/span')).click();
		browser.sleep(2000);

		console.log('VakantiepakketGezinFR: Valideer prijs');
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 643');
		});
	});

	it('VakantiepakketGezinFR: Klik op volgende knop', function () {
        console.log('VakantiepakketGezinFR: Klik op volgende knop');
        var elementToScroll = element(by.xpath('/html/body/section[4]'));
        browser.actions().mouseMove(elementToScroll).perform();
        browser.sleep(2000);
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/div/a')).click();
        browser.sleep(2000);
	});

	it('VakantiepakketGezinFR: Valideer nieuwe pagina 1/4', function () {
		console.log('VakantiepakketGezinFR: Valideer nieuwe pagina 1/4');
		var ele = element(by.className('h1 vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: Valideer resultaat tekst");

		element(by.className('h1 vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe(common.vakantiepakketTitelFR);
			browser.sleep(2000);
		});
	});

	it('VakantiepakketGezinFR: Valideer prijs', function () {
		console.log('VakantiepakketGezinFR: Valideer prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 643');
		});
	});

	it('VakantiepakketGezinFR: Vul gegevens in', function () {
		console.log('VakantiepakketGezinFR: Vul gegevens in');
		console.log('VakantiepakketGezinFR: Persoon 1');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[1]/div/div/label[1]/input')).sendKeys(common.userFirstName);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[1]/div/div/label[2]/input')).sendKeys(common.userLastName);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[1]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);

		// Validation needs to have focus
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
		browser.sleep(2000);

		console.log('VakantiepakketGezinFR: Persoon 2');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[2]/div/div/label[1]/input')).sendKeys('TESTVAB2-Firstname');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[2]/div/div/label[2]/input')).sendKeys('TESTVAB2-Lastname');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[2]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys('01/04/2001');

		// Validation needs to have focus
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
		browser.sleep(2000);
	});

	it('VakantiepakketGezinFR: Vul nummerplaten in', function () {
		console.log('VakantiepakketGezinFR: Vul nummerplaten in');
		console.log('VakantiepakketGezinFR: Nummerplaat 1');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[5]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[1]/div/div/label[1]/input')).sendKeys('VROOM1');
		browser.sleep(2000);

		console.log('VakantiepakketGezinFR: Nummerplaat 2');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[5]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[2]/div/div/label[1]/input')).sendKeys('VROOM2');
		browser.sleep(3000);

		
	});

	it('VakantiepakketGezinFR: Voeg medereiziger toe', function () {
		console.log('VakantiepakketGezinFR: Voeg medereiziger toe');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/label[1]/span[1]')).click();
		browser.sleep(3000);

		console.log('VakantiepakketGezinFR: Wacht tot medereiziger regio is geladen');
		var ele = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[1]/div/div[2]/div/div/label/app-new-datepicker/div/input'));
		browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: Wait for travellers region");
	});

	it('VakantiepakketGezinFR: Voer einddatum in langer verblijf', function () {
		console.log('VakantiepakketGezinFR: Voer einddatum in langer verblijf');
		var endDatePersonAssurance = dateFunctions.addTotalDays(7);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[1]/div/div[2]/div/div/label/app-new-datepicker/div/input')).sendKeys(endDatePersonAssurance);
		browser.sleep(2000);

		// Validation needs to have focus	
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[1]/div/div/label[1]/input')).click();
		browser.sleep(10000);
	});

	it('VakantiepakketGezinFR: Valideer prijs', function () {
		console.log('VakantiepakketGezinFR: Valideer prijs');
		element(by.className("vab__calculator__form__price")).getText().then(function (text) {
			expect(text).toBe('€ 668');
			browser.sleep(3000);
		});
	});

	it('VakantiepakketGezinFR: Medereiziger 1', function () {
		console.log('VakantiepakketGezinFR: Medereiziger 1');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[1]/div/div/label[1]/input')).sendKeys('TESTVAB1_First');
		browser.sleep(3000);

		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[1]/div/div/label[2]/input')).sendKeys('TESTVAB1_Last');
		browser.sleep(3000);

		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[1]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys('13/08/1991');
		browser.sleep(2000);

		// Validation needs to have focus	
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[1]/div/div/label[2]/input')).click();
		browser.sleep(10000);

		console.log('VakantiepakketGezinFR: Valideer prijs');
		element(by.className("vab__calculator__form__price")).getText().then(function (text) {
			expect(text).toBe('€ 668');
		});
	});

	it('VakantiepakketGezinFR: Medereiziger 2', function () {
		console.log('VakantiepakketGezinFR: Medereiziger 2');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/label[1]/span[1]')).click();
		browser.sleep(3000);

		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler/div/div/label[1]/input')).sendKeys('TESTVAB2_First');
		browser.sleep(3000);

		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler/div/div/label[2]/input')).sendKeys('TESTVAB2_Last');
		browser.sleep(3000);

		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler/div/div/label[3]/app-new-datepicker/div/input')).sendKeys('13/08/1992');
		browser.sleep(2000);

		console.log('VakantiepakketGezinFR: Valideer prijs');
		element(by.className("vab__calculator__form__price")).getText().then(function (text) {
			expect(text).toBe('€ 668');
		});

		// Validation needs to have focus	
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
		browser.sleep(2000);
	});

	it('VakantiepakketGezinFR: Bevestig correcte gegevens', function () {
		console.log('VakantiepakketGezinFR: Bevestig correcte gegevens');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/label/span[1]')).click();
	})

	it('VakantiepakketGezinFR: Klik op volgende knop', function () {
		console.log('VakantiepakketGezinFR: Klik op volgende knop');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[4]/div[1]/a')).click();
		browser.sleep(2000);
		browser.ignoreSynchronization = true;
	});

	it('VakantiepakketGezinFR: Valideer nieuwe pagina 2/4', function () {
		console.log('VakantiepakketGezinFR: Valideer nieuwe pagina 2/4');
		var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: Valideer pagina 2/4");

		element(by.className('vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('Étape 2 sur 4 : Données');
			browser.sleep(2000);
		});

		console.log('VakantiepakketGezinFR: Valideer prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 668');
		});
	});

	it('VakantiepakketGezinFR: Vul adres in', function () {
		console.log('VakantiepakketGezinFR: Vul adres in');
		common.zipcode.sendKeys(common.userZipcode);
		common.city.sendKeys(common.userCity);
		common.street.sendKeys(common.userStreet);
		common.houseNumber.sendKeys(common.userHouseNumber);
		browser.sleep(2000);
	});

	it('VakantiepakketGezinFR: Vul email in', function () {
		console.log('VakantiepakketGezinFR: Vul email in');
		common.email.sendKeys(common.userEmail);
		browser.sleep(2000);
	});

	it('VakantiepakketGezinFR: Klik checkbox algemene voorwaarden', function () {
		console.log('VakantiepakketGezinFR: Klik checkbox algemene voorwaarden');
		common.checkboxGeneralTerms.click();
		browser.sleep(2000);
	});

	it('VakantiepakketGezinFR: Klik op volgende knop', function () {
		console.log("VakantiepakketGezinFR: Klik op volgende knop");
		common.nextButton.click();
		browser.sleep(2000);
	});

	it('VakantiepakketGezinFR: Valideer nieuwe pagina 3/4', function () {
		console.log('VakantiepakketGezinFR: Valideer nieuwe pagina 3/4');
		var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: Valideer pagina 3/4");

		element(by.className('vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('Étape 3 sur 4 : Analyse des besoins');
		});

		console.log('VakantiepakketGezinFR: Valideer prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 668');
		});
	});

	it('VakantiepakketGezinFR: Vul behoefteanalyse pagina in', function () {
		console.log('VakantiepakketGezinFR: Vul behoefteanalyse pagina in');
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[3]/label[1]/span[2]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[4]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[5]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[1]/span[2]')).click();
		browser.sleep(2000);
	});

	it('VakantiepakketGezinFR: Klik op toon resultaat', function () {
		console.log('VakantiepakketGezinFR: Klik op toon resultaat');
		element(by.id('submitBtn')).click();
		browser.sleep(2000);
	});

	it('VakantiepakketGezinFR: Valideer resultaat tekst', function () {
		console.log('VakantiepakketGezinFR: Valideer resultaat tekst');
		var ele = element(by.xpath('//*[@id="scrollToHere"]/p[1]'));
		browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: Valideer resultaat tekst");

		element(by.xpath('//*[@id="scrollToHere"]/p[1]')).getText().then(function (text) {
			expect(text).toBe("Sur base de vos réponses, nous vous recommandons le produit suivant : Formule vacances avec bagages temporaire seul");
			browser.sleep(5000);
		});

	});

	it('VakantiepakketGezinFR: Klik op volgende knop', function () {
		console.log('VakantiepakketGezinFR: Wacht op volgende knop');
		var nextBtn = element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[8]/a[2]/span'));
		browser.wait(EC.visibilityOf(nextBtn), 50000, "Timeout of VisibilityOf: Next Button");

		console.log('VakantiepakketGezinFR: Klik op volgende knop');
		nextBtn.click();
		browser.sleep(2000);
	});

	it('VakantiepakketGezinFR: Valideer nieuwe pagina 4/4', function () {
		console.log('VakantiepakketGezinFR: Valideer nieuwe pagina 4/4');
		var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: Stap 4 van 4: Betaling");

		element(by.className('vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('Étape 4 sur 4 : Paiement');
		});

		console.log('VakantiepakketGezinFR: Valideer prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 668');
		});
	});
	if (common.payment) {
		it('Betaalstap selecteer Visa', function () {
			paymentFunctions.visaPayment();
		});
	};
});
