var Common = require('./VABCommon/common.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
describe("Buy a product: MultipakketGezinFR", function () {
	var common = new Common();
	var applicationURL = common.applicationURL;
	var EC = protractor.ExpectedConditions;

	it('MultipakketGezinFR: Open browser & accepteer cookies', function () {
		console.log('MultipakketGezinFR: Open browser & accepteer cookies');
		browser.get(applicationURL + '/fr/assistance/assistance-voyage/formule-multi');
		browser.sleep(2000);
		common.cookie.click();
		browser.sleep(2000);
		browser.waitForAngularEnabled(false);
	});

	it('MultipakketGezinFR: Valideer prijs', function () {
		console.log('MultipakketGezinFR: Valideer prijs');
		var ele = element(by.className("vab__intro__title vab__heading--2"));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Bijstand op reis");

		element(by.className('vab__calculator__form__theHeading')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe(common.berekenPrijsTitelFR);
		});

		console.log('MultipakketGezinFR: Valideer prijs');
		element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 345');
		});
	});

	it('MultipakketGezinFR: Selecteer optie gezin', function () {
		console.log('MultipakketGezinFR:Selecteer optie gezin');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div/div/div/div[2]/div/div/label/span[2]')).click();
		browser.sleep(2000);
		element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 429');
		});
	});

	it('MultipakketGezinFR: Voeg extra voertuig toe', function () {
		console.log('MultipakketGezinFR: Voeg extra voertuig toe');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[1]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);
		element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 539');
		});
	});

	it('MultipakketGezinFR: Voeg extra vervangwagen toe', function () {
		console.log('MultipakketGezinFR: Voeg extra vervangwagen toe');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[2]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);
		element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 623');
		});

		console.log('MultipakketGezinFR: Voeg extra vervangwagen toe');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[2]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);
		element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 707');
		});
	});

	it('MultipakketGezinFR: Voeg optie camper toe', function () {
		console.log('MultipakketGezinFR: Voeg optie camper toe');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[3]/div/label/div/div/span')).click();
		browser.sleep(2000);
		element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 801');
		});
	});

	it('MultipakketGezinFR: Klik op volgende knop', function () {
		console.log('MultipakketGezinFR: Klik op volgende knop');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/div/a/span')).click();
		browser.sleep(2000);
	});

	it('MultipakketGezinFR: Valideer nieuwe pagina 1/4', function () {
		console.log('MultipakketGezinFR: Valideer nieuwe pagina 1/4');
		var ele = element(by.className('h1 vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 1 van 4");

		element(by.className('h1 vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe(common.multipakketTitelFR);
		});

		console.log('MultipakketGezinFR: Valideer prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 801');
		});
	});

	it('MultipakketGezinFR: Vul gegevens in van persoon 1', function () {
		console.log('MultipakketGezinFR: Vul gegevens in van persoon 1');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[1]/div/div/label[1]/input')).sendKeys(common.userFirstName);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[1]/div/div/label[2]/input')).sendKeys(common.userLastName);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[1]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);

		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
		browser.sleep(2000);
	});

	it('MultipakketGezinFR: Vul gegevens in van persoon 2', function () {
		console.log('MultipakketGezinFR: Vul gegevens in van persoon 2');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[2]/div/div/label[1]/input')).sendKeys(common.userFirstName + "2");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[2]/div/div/label[2]/input')).sendKeys(common.userLastName + "2");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[2]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);

		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
		browser.sleep(2000);
	});

	it('MultipakketGezinFR: Vul nummerplaten in', function () {
		console.log('MultipakketGezinFR: Vul nummerplaten in');
		console.log('VakantiepakketGezinFR: Nummerplaat 1');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[5]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[1]/div/div/label[1]/input')).sendKeys('NOTABOAT');
		browser.sleep(2000);

		console.log('VakantiepakketGezinFR: Nummerplaat 2');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[5]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[2]/div/div/label[1]/input')).sendKeys('NOTABOAT2');
		browser.sleep(2000);
	});

	it('MultipakketGezinFR: Bevestig correcte gegevens', function () {
		console.log('MultipakketGezinFR: Bevestig correcte gegevens');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/label/span[1]')).click();
	})
	it('MultipakketGezinFR: Klik op volgende knop', function () {
		console.log('MultipakketGezinFR:  Klik op volgende knop');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[4]/div[1]/a')).click();
		browser.sleep(2000);
	});

	it('MultipakketGezinFR: Valideer nieuwe pagina 2/4', function () {
		console.log('MultipakketGezinFR:  Valideer nieuwe pagina 2/4');
		var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 2 van 4: Gegevens");

		element(by.className('vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('Étape 2 sur 4 : Données');
		});

		console.log('MultipakketGezinFR: Valideer Prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 801');
		});
	});

	it('MultipakketGezinFR: Vul adres gegevens in', function () {
		console.log('MultipakketGezinFR:  Vul adres gegevens in');
		common.zipcode.sendKeys(common.userZipcode);
		common.city.sendKeys(common.userCity);
		common.street.sendKeys(common.userStreet);
		common.houseNumber.sendKeys(common.userHouseNumber);
	});

	it('MultipakketGezinFR: Vul email in', function () {
		console.log('MultipakketGezinFR: Vul email in');
		common.email.sendKeys(common.userEmail);
		browser.sleep(2000);
	});

	it('MultipakketGezinFR: Klik checkbox algemene voorwaarden', function () {
		console.log('MultipakketGezinFR: Klik checkbox algemene voorwaarden');
		element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/label[1]/span[1]')).click();
		browser.sleep(2000);
	});

	it('MultipakketGezinFR: Volgende knop', function () {
		console.log('MultipakketGezinFR: Volgende knop');
		common.nextButton.click();
		browser.sleep(2000);
	});

	it('MultipakketGezinFR: Valideer nieuwe pagina 3/4', function () {
		console.log('MultipakketGezinFR: Valideer nieuwe pagina 3/4: Behoefteanalyse');
		var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 3 van 4");

		element(by.className('vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('Étape 3 sur 4 : Analyse des besoins');
		});

		console.log('MultipakketGezinFR: Valideer Prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 801');
		});
	});

	it('MultipakketGezinFR: Vul behoefteanalyse pagina in', function () {
		console.log('MultipakketGezinFR: Vul behoefteanalyse pagina in');
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[3]/label[1]/span[2]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[4]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[5]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[1]/span[2]')).click();
		browser.sleep(2000);
	});

	it('MultipakketGezinFR: Klik op toon resultaat', function () {
		console.log('MultipakketGezinFR: Klik op toon resultaat');
		element(by.id('submitBtn')).click();
		browser.sleep(4000);
	});

	it('MultipakketGezinFR: Valideer resultaat tekst', function () {
		console.log('MultipakketGezinFR: Valideer resultaat tekst');
		element(by.xpath('//*[@id="scrollToHere"]/p[1]')).getText().then(function (text) {
			expect(text).toBe("Sur base de vos réponses, nous vous recommandons le produit suivant : Formule vacances avec bagages temporaire seul");
		});
	});

	it('MultipakketGezinFR: Klik op volgende knop', function () {
		console.log('MultipakketGezinFR: Klik op volgende knop');
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[8]/a[2]/span')).click();
		browser.sleep(3000);
	});

	it('MultipakketGezinFR: Valideer nieuwe pagina 4/4', function () {
		console.log('MultipakketGezinFR: Valideer nieuwe pagina 4/4');
		var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 4 van 4");

		element(by.className('vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('Étape 4 sur 4 : Paiement');
		});

		console.log('MultipakketGezinFR: Valideer Prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 801');
		});
	});
	if (common.payment) {
		it('Betaalstap selecteer MasterCard', function () {
			paymentFunctions.masterCardPayment();
		});
	};
});
