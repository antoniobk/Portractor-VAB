var Common = require('./VABCommon/common.js');
var dateFunctions = require('./VABCommon/dateFunctions.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
describe("VakantiepakketSingleNL: Buy a product: Vakantiepakket Single", function () {
	var common = new Common();
	var EC = protractor.ExpectedConditions;

	it('VakantiepakketSingleNL: Open browser & accepteer cookies', function () {
		console.log('VakantiepakketSingleNL: Open browser & accepteer cookies');
		browser.get(common.applicationURL + '/nl/pech-en-reisbijstand/bijstand-op-reis/vakantiepakket');
		common.cookie.click();
		browser.sleep(2000);
		browser.waitForAngularEnabled(false);
	});


	it('VakantiepakketSingleNL: Valideer prijs', function () {
		console.log('VakantiepakketSingleNL: Valideer prijs');
		var ele = element(by.className("vab__calculator__form__theHeading"));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: HomePage Vakantiepakket");

		element(by.className('vab__calculator__form__theHeading')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('Bereken je tarief');
		});

		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 213');
		});
		browser.sleep(2000);

		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[1]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);

		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 230');
		});

		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[2]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 266');
		});

		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[1]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 283');
		});

		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[2]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 319');
		});

		console.log('VakantiepakketSingleNL: Optie motorhome');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[3]/div/label/div/div/span')).click();
		browser.sleep(2000);
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 384');
		});

		console.log('VakantiepakketSingleNL: Optie bagage');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[5]/div/label/div/div/span')).click();
		browser.sleep(2000);
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 491');
		});

		console.log('VakantiepakketSingleNL: Optie annulatieverzekering');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[6]/div/label/div/div/span')).click();
		browser.sleep(2000);
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 567');
		});
	});

	it('VakantiepakketSingleNL: Klik op volgende knop', function () {
		console.log('VakantiepakketSingleNL: Klik op volgende knop');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/div/a')).click();
		browser.sleep(2000);
	});


	it('VakantiepakketSingleNL: Valideer nieuwe pagina 1/4', function () {
		console.log('VakantiepakketSingleNL: Valideer nieuwe pagina 1/4');
		var ele = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[1]/div[1]/h1'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 1 van 4: Jouw VAB-Vakantiepakket");

		element(by.className('h1 vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('Stap 1 van 4: Jouw VAB-Vakantiepakket');
		});
	});

	it('VakantiepakketSingleNL: Valideer prijs', function () {
		console.log('VakantiepakketSingleNL: Valideer prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 567');
		});
	});

	it('VakantiepakketSingleNL: Vul gegevens in', function () {
		console.log('VakantiepakketSingleNL: Vul gegevens in');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div[1]/app-person/div/div[1]/label[1]/input')).sendKeys(common.userFirstName);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div[1]/app-person/div/div[1]/label[2]/input')).sendKeys(common.userLastName);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div[1]/app-person/div/div[1]/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);

		// Validation needs to have focus
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
		browser.sleep(2000);
	});

	it('VakantiepakketSingleNL: Vul langer verblijf in', function () {
		console.log('VakantiepakketSingleNL: Vul langer verblijf in');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-stay-option/div/label[1]/span[1]')).click();
		browser.sleep(2000);

		console.log('VakantiepakketSingleNL: Vul startDate in');
		var startDate = dateFunctions.getFutureDate(1, 2);

		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-stay-option/div/div/div[1]/div/div[1]/div/div/label/app-new-datepicker/div/input')).sendKeys(startDate);
		browser.sleep(2000);


		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
		browser.sleep(2000);

		console.log('VakantiepakketSingleNL: Vul endDate in');
		var endDate = dateFunctions.addTotalDaysReferenceDate(startDate, 121);

		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-stay-option/div/div/div[1]/div/div[2]/div/div/label/app-new-datepicker/div/input')).sendKeys(endDate);
		browser.sleep(2000);

		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
		browser.sleep(2000);
	});

	it('VakantiepakketSingleNL: Valideer prijs', function () {
		console.log("VakantiepakketSingleNL: Valideer prijs");
		element(by.className("vab__calculator__form__price")).getText().then(function (text) {
			expect(text).toBe('€ 615');
		});
	});

	it('VakantiepakketSingleNL: Vul nummerplaten in', function () {
		console.log('VakantiepakketSingleNL: Vul nummerplaten in');

		console.log('VakantiepakketSingleNL: Nummerplaat 1');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[5]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[1]/div/div/label[1]/input')).sendKeys('VROOM1');
		browser.sleep(2000);

		console.log('VakantiepakketSingleNL: Nummerplaat 2');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[5]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[2]/div/div/label[1]/input')).sendKeys('VROOM2');

		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
		browser.sleep(2000);
	});

	it('VakantiepakketSingleNL: Medereizigers - Personenbijstand', function () {
		console.log('VakantiepakketSingleNL: Medereizigers - Personenbijstand');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/label[1]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/label[1]')).click();
		browser.sleep(2000);

		console.log('VakantiepakketSingleNL: Klik op wereldwijd');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/label[2]/span[1]')).click();

		console.log('VakantiepakketSingleNL: Vul einddatum reis in');
		var endDatePersonAssurance = dateFunctions.addTotalDays(21);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[1]/div/div[2]/div/div/label/app-new-datepicker/div/input')).sendKeys(endDatePersonAssurance);
		browser.sleep(2000);

		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler/div/div/label[1]/input')).click();
		browser.sleep(2000);

		console.log('VakantiepakketSingleNL: Valideer Prijs');
		element(by.className("vab__calculator__form__price")).getText().then(function (text) {
			expect(text).toBe('€ 741');
		});
	});

	it('VakantiepakketSingleNL: Medereizigers - Gegevens', function () {
		console.log('VakantiepakketSingleNL: Medereiziger - Gegevens');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler/div/div/label[1]/input')).sendKeys('TESTVAB1_First');
		browser.sleep(2000);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler/div/div/label[2]/input')).sendKeys('TESTVAB1_Last');
		browser.sleep(2000);
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler/div/div/label[3]/app-new-datepicker/div/input')).sendKeys('13/08/1991');
		browser.sleep(2000);

		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler/div/div/label[1]/input')).click();
		browser.sleep(2000);

		console.log('VakantiepakketSingleNL: Valideer Prijs');
		element(by.className("vab__calculator__form__price")).getText().then(function (text) {
			expect(text).toBe('€ 741');
		});
	});

	it('VakantiepakketSingleNL: Bevestig dat gegevens correct zijn', function () {
		console.log('VakantiePakketSingleNL: Bevestig dat gegevens correct zijn');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/label/span[1]')).click();
	})

	it('VakantiepakketSingleNL: Klik op volgende knop', function () {
		console.log('VakantiepakketSingleNL: Klik op volgende knop');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[4]/div[1]/a')).click();
	});

	it('VakantiepakketSingleNL: Valideer nieuwe pagina 2/4', function () {
		console.log('VakantiepakketSingleNL: Valideer nieuwe pagina 2/4');
		var ele = element(by.xpath('//*[@id="thefunnelform"]/div/div[1]/div[1]/p'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 2 van 4: Gegevens");

		element(by.className('vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('Stap 2 van 4: Gegevens');
		});

		console.log('VakantiepakketSingleNL: Valideer Prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 741');
		});
	});

	it('VakantiepakketSingleNL: Vul adres in', function () {
		console.log('VakantiepakketSingleNL: Vul adres in');
		common.zipcode.sendKeys(common.userZipcode);
		common.city.sendKeys(common.userCity);
		common.street.sendKeys(common.userStreet);
		common.houseNumber.sendKeys(common.userHouseNumber);
		browser.sleep(2000);
	});

	it('VakantiepakketSingleNL: Vul email in', function () {
		console.log('VakantiepakketSingleNL: Vul email in');
		common.email.sendKeys(common.userEmail);
		browser.sleep(2000);
	});

	it('VakantiepakketSingleNL: Klik checkbox algemene voorwaarden', function () {
		console.log('VakantiepakketSingleNL: Klik checkbox algemene voorwaarden');
		common.checkboxGeneralTerms.click();
		browser.sleep(2000);
	});

	it('VakantiepakketSingleNL: Klik op volgende knop', function () {
		console.log("VakantiepakketSingleNL: Klik op volgende knop");
		common.nextButton.click();
		browser.sleep(2000);
	});

	it('VakantiepakketSingleNL: Valideer nieuwe pagina 3/4', function () {
		console.log('VakantiepakketSingleNL: Valideer nieuwe pagina 3/4');
		var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 3 van 4: Behoefteanalyse");

		element(by.className('vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('Stap 3 van 4: Behoefteanalyse');
		});

		console.log('VakantiepakketSingleNL: Valideer Prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 741');
		});
	});

	it('VakantiepakketSingleNL: Vul behoefteanalyse pagina in', function () {
		console.log('VakantiepakketSingleNL: Vul behoefteanalyse pagina in');
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[3]/label[1]/span[2]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[4]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[5]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[1]/span[2]')).click();
		browser.sleep(2000);
	});

	it('VakantiepakketSingleNL: Klik op toon resultaat', function () {
		console.log('VakantiepakketSingleNL: Klik op toon resultaat');
		element(by.id('submitBtn')).click();
		browser.sleep(3000);
	});

	it('VakantiepakketSingleNL: Valideer resultaat tekst', function () {
		console.log('VakantiepakketSingleNL: Valideer resultaat tekst');
		element(by.xpath('//*[@id="scrollToHere"]/p[1]')).getText().then(function (text) {
			expect(text).toBe(common.behoefteAnalyseTijdelijkeNL);
		});
	});

	it('VakantiepakketSingleNL: Klik op volgende knop', function () {
		console.log('VakantiepakketSingleNL: Klik op volgende knop');
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[8]/a[2]/span')).click();
		browser.sleep(5000);
	});

	it('VakantiepakketSingleNL: Valideer nieuwe pagina 4/4', function () {
		console.log('VakantiepakketSingleNL: Valideer nieuwe pagina 4/4');
		var ele = element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/div/div[1]/div[1]/p'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 4 van 4: Betaling");

		element(by.className('vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('Stap 4 van 4: Betaling');
		});

		console.log('VakantiepakketSingleNL: Valideer Prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 741');
			browser.sleep(4000);
		});
	});

	it('VakantiepakketSingleNL: Vul vouchercode in', function () {
		console.log('VakantiepakketSingleNL: Vul vouchercode in');
        paymentFunctions.setVoucherCode(false);

		console.log('VakantiepakketSingleNL: Valideer Prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 675,9');

		});
	});
	if (common.payment) {
		it('Betaalstap selecteer MasterCard', function () {
			paymentFunctions.masterCardPayment();
		});
	};
});

