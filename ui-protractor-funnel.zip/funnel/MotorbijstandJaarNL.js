var Common = require('./VABCommon/common.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
describe("MotorBijstandJaarNL: Buy a product: Motor (Jaarbijstand)", function () {
    var common = new Common();
    var applicationURL = common.applicationURL;
    var EC = protractor.ExpectedConditions;

    it('MotorBijstandJaarNL: Open browser & accepteer cookies', function () {
        console.log('MotorBijstandJaarNL: Open browser & accepteer cookies');
        browser.waitForAngularEnabled(false);
        browser.get(applicationURL + '/nl/pech-en-reisbijstand/auto-en-motor/motorbijstand');

        browser.sleep(2000);
        common.cookie.click();
        browser.sleep(2000);
    });

    it('MotorBijstandJaarNL: Valideer prijs', function () {
        console.log("MotorBijstandJaarNL: Valideer prijs");        
        //TODO: Check if this is still necessary:
        //var elementToScrollTo = element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/p'));
        //browser.actions().mouseMove(elementToScrollTo).perform();

        var ele = element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/p'));
        browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: HomePage of Motorbijstand");

        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/p')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 77');
        });
    });

    it('MotorBijstandJaarNL: Klik op jaarcontract', function () {
        console.log('MotorBijstandJaarNL: Klik op jaarcontract');
        browser.element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div/div/div/div[2]/div/div/label/span[2]')).click();
        browser.sleep(3000);
    });

    it('MotorBijstandJaarNL: Valideer prijs', function () {
        console.log("MotorBijstandJaarNL: Valideer prijs");
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 128');
        });
    });

    it('MotorBijstandJaarNL: Voeg extra motor toe', function () {
        console.log('MotorBijstandJaarNL: Voeg extra motor toe');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
        browser.sleep(3000);
    });

    it('MotorBijstandJaarNL: Valideer prijs', function () {
        console.log("MotorBijstandJaarNL: Valideer prijs");
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (updatedPricing) {
            expect(updatedPricing).toBe('€ 238');
        });
    });

    it('MotorBijstandJaarNL: Klik op volgende knop', function () {
        console.log("MotorBijstandJaarNL: Klik op volgende knop");
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/div/a/span')).click();
        browser.sleep(4000);
    });

    it('MotorBijstandJaarNL: Valideer nieuwe pagina 1/3', function () {
        console.log('MotorBijstandJaarNL: Valideer nieuwe pagina 1/3');
        var ele = element(by.className("vab__calculator__form__price"));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Valideer nieuwe pagina 1/3");

        element(by.className("h1 vab__fs--2 vab__ff--special-1")).getText().then(function (text) {
            expect(text).toBe('Stap 1 van 3: Jouw VAB-Motorbijstand');
        });
    });

    it('MotorBijstandJaarNL: Valideer prijs', function () {
        console.log('MotorBijstandJaarNL: Valideer prijs');
        element(by.className('vab__calculator__form__price')).getText().then(function (updatedPricing) {
            expect(updatedPricing).toBe('€ 238');
        });
    });

    it('MotorBijstandJaarNL: Vul nummerplaten in', function () {
        console.log('MotorBijstandJaarNL: Vul nummerplaten in');
        common.licensePlateOne.sendKeys("ABCDEF");
        browser.sleep(3000);
        common.licensePlateTwo.sendKeys("123456");
        browser.sleep(3000);
        
        common.licensePlateOne.click();
        browser.sleep(3000);
    });

    it('MotorBijstandJaarNL: Klik op volgende knop', function () {    
        console.log('MotorBijstandJaarNL: Klik op volgende knop');
        //TODO: Check if this is still necessary:
        //var elementToScrollToVolgendeKnop = element(by.xpath("//span[@class='vab__button__label'][contains(text(),'Volgende')]"));
        //browser.actions().mouseMove(elementToScrollToVolgendeKnop).perform();
        element(by.xpath("//span[@class='vab__button__label'][contains(text(),'Volgende')]")).click();
        browser.sleep(2000);
    });

    it('MotorBijstandJaarNL: Valideer nieuwe pagina 2/3', function () {
        console.log("MotorBijstandJaarNL: Valideer nieuwe pagina 2/3");
        browser.waitForAngularEnabled(false);
        browser.wait(EC.visibilityOf(element(by.xpath('//*[@id="thefunnelform"]/div/div[1]/div[1]/p '))), 30000, "Timeout of VisibilityOf: Stap 2 van 3: Gegevens");

        element(by.xpath('//*[@id="thefunnelform"]/div/div[1]/div[1]/p')).getText().then(function (text) {
            expect(text).toBe('Stap 2 van 3: Gegevens');
        });
    });

    it('MotorBijstandJaarNL: Valideer prijs', function () {
        console.log('MotorBijstandJaarNL: Valideer prijs');
        element(by.className('vab__calculator__form__price')).getText().then(function (updatedPricing3) {
            expect(updatedPricing3).toBe('€ 238');
        });
    });

    it('MotorBijstandJaarNL: Vul gegevens in', function () {
        console.log('MotorBijstandJaarNL: Vul gegevens in');
        common.firstName.sendKeys(common.userFirstName);
        common.lastName.sendKeys(common.userLastName);
        common.datepicker.sendKeys(common.userBirthDate);
        browser.sleep(2000);
    });

    it('MotorBijstandJaarNL: Vul adres in', function () {
        console.log('MotorBijstandJaarNL: Vul adres in');
        common.zipcode.sendKeys(common.userZipcode);
        common.city.sendKeys(common.userCity);
        common.street.sendKeys(common.userStreet);
        common.houseNumber.sendKeys(common.userHouseNumber);
    });

    it('MotorBijstandJaarNL: Vul email in', function () {
        console.log('MotorBijstandJaarNL: Vul email in');
        common.email.sendKeys(common.userEmail);
        browser.sleep(2000);
    });

    it('MotorBijstandJaarNL: Klik checkbox algemene voorwaarden', function () {
        console.log('MotorBijstandJaarNL: Klik checkbox algemene voorwaarden');
        common.checkboxGeneralTerms.click();
    });

    it('MotorBijstandJaarNL: Klik op volgende knop', function () {
        console.log("MotorBijstandJaarNL: Klik op volgende knop");
        browser.sleep(2000);
        common.nextButton.click();
        browser.sleep(2000);
    });

    it('MotorBijstandJaarNL: Valideer nieuwe pagina 3/3', function () {
        console.log("MotorBijstandJaarNL: Valideer nieuwe pagina 3/3");
        element(by.className('vab__fs--2 vab__ff--special-1')).getText().then(function (text) {
            expect(text).toBe('Stap 3 van 3: Betaling');
        });
    });

    it('MotorBijstandJaarNL: Valideer prijs', function () {
        console.log('MotorBijstandJaarNL: Valideer prijs');
        browser.sleep(2000);
        element(by.className('vab__calculator__form__price')).getText().then(function (updatedPricing4) {
            expect(updatedPricing4).toBe('€ 238');
        });
    });
    if (common.payment) {
        it(' Selecteer CBC', function () {
            paymentFunctions.cbcPayment();
        });
    };
});