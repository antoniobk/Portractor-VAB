var Common = require('./VABcommon/common.js');
var dateFunctions = require('./VABCommon/dateFunctions.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
describe("ReisbijstandGezinFR: Buy a product: Reisbijstand", function () {
    var common = new Common();
    var applicationURL = common.applicationURL;
    var EC = protractor.ExpectedConditions;

    it('ReisbijstandGezinFR: Open browser & accepteer cookies', function () {
        console.log('ReisbijstandGezinFR: Open browser & accepteer cookies');
        browser.get(applicationURL + '/fr/assistance/assistance-voyage/assistance-voyage');
        browser.sleep(2000);
        common.cookie.click();
    });

    it('ReisbijstandGezinFR: Valideer prijs', function () {
        console.log('ReisbijstandGezinFR: Valideer prijs');
        var ele = element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/div/div/div/div[1]/header'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout on VisibilityOf: Reisbijstand homepage");

        var myElement = element(by.className('vab__intro__title vab__heading--2'));
        expect(myElement.isPresent()).toBe(true);

        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 92');
        });
    });

    it('ReisbijstandGezinFR: Selecteer Gezin', function () {
        console.log('ReisbijstandGezinFR: Selecteer Gezin');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div/div/div/div[2]/div/div/label/span[1]')).click();
        browser.sleep(2000);

        console.log('ReisbijstandGezinFR: Valideer Prijs');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 116');
        });
    });

    it('ReisbijstandGezinFR: Voeg voertuig 1 toe', function () {
        console.log('ReisbijstandGezinFR: Voeg voertuig 1 toe');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[1]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
        browser.sleep(2000);

        console.log('ReisbijstandGezinFR: Valideer Prijs');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 133');
        });
    });

    it('ReisbijstandGezinFR: Voeg voertuig 2 toe', function () {
        console.log('ReisbijstandGezinFR: Voeg voertuig 2 toe');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[1]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
        browser.sleep(2000);

        console.log('ReisbijstandGezinFR: Valideer Prijs');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 150');
        });
    });

    it('ReisbijstandGezinFR: Voeg vervangwagen buitenland 1 toe', function () {
        console.log('ReisbijstandGezinFR: Voeg vervangwagen buitenland 1 toe');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[2]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
        browser.sleep(2000);

        console.log('ReisbijstandGezinFR: Valideer Prijs');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 186');
        });
    });

    it('ReisbijstandGezinFR: Voeg vervangwagen buitenland 2 toe', function () {
        console.log('ReisbijstandGezinFR: Voeg vervangwagen buitenland 2 toe');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[2]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
        browser.sleep(2000);

        console.log('ReisbijstandGezinFR: Valideer Prijs');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 222');
        });
    });

    it('ReisbijstandGezinFR: Voeg motorhome buitenland 1 toe', function () {
        console.log('ReisbijstandGezinFR: Voeg motorhome buitenland 1 toe');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[3]/div/label/div/div/span')).click();
        browser.sleep(2000);

        console.log('ReisbijstandGezinFR: Valideer Prijs');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 287');
        });
    });

    it('ReisbijstandGezinFR: Voeg bagageverzekering toe', function () {
        console.log('ReisbijstandGezinFR: Voeg bagageverzekering toe');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[4]/div/label/div/div/span')).click();
        browser.sleep(2000);

        console.log('ReisbijstandGezinFR: Valideer Prijs');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 459');
        });
    });

    it('ReisbijstandGezinFR: Klik op bestel online knop', function () {
        console.log('ReisbijstandGezinFR: Klik op volgende knop');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/div/a/span')).click();
        browser.sleep(2000);
    });

    it('ReisbijstandGezinFR: Valideer nieuwe pagina 1/4', function () {
        console.log('ReisbijstandGezinFR: Valideer nieuwe pagina 1/4');
        var ele = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[1]/a/div'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout on VisibilityOf: Reisbijstand Stap 1");

        element(by.className("h1 vab__fs--2 vab__ff--special-1")).getText().then(function (text) {
            expect(text).toBe(common.reisbijstandTitleFR);
        });

        element(by.className("vab__calculator__form__price")).getText().then(function (text) {
            expect(text).toBe('€ 459');
        });
    });

    it('ReisbijstandGezinFR: Vul gegevens in persoon 1', function () {
        console.log('ReisbijstandGezinFR: Vul gegevens in persoon 1');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[1]/div/div/label[1]/input')).sendKeys('TESTVAB-Firstname');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[1]/div/div/label[2]/input')).sendKeys('TESTVAB-Lastname');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[1]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys('13/08/1991');
        browser.sleep(2000);

        //Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[1]/div/div/label[1]/input')).click();
        browser.sleep(2000);
    });

    it('ReisbijstandGezinFR: Vul gegevens in persoon 2', function () {
        console.log('ReisbijstandGezinFR: Persoon 2');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[2]/div/div/label[1]/input')).sendKeys('TESTVAB-Firstname2');
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[2]/div/div/label[2]/input')).sendKeys('TESTVAB-Lastname2');
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[2]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys('10/05/1995');
        browser.sleep(2000)
        
        console.log('Wijzig focus door validaties');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[2]/div/div/label[1]/input')).click();
        browser.sleep(2000);
        
        console.log('ReisbijstandGezinFR: Nummerplaat 1');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[5]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[1]/div/div/label[1]/input')).click();
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[5]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[1]/div/div/label[1]/input')).sendKeys('XYZ-987');
        browser.sleep(2000);

        console.log('ReisbijstandGezinFR: Nummerplaat 2');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[5]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[2]/div/div/label[1]/input')).sendKeys('VAB-007');
        browser.sleep(2000);
    });


    it('ReisbijstandGezinFR: Medereizigers', function () {
        console.log('ReisbijstandGezinFR: Medereizigers');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/label[1]/span[2]')).click();
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/label[2]/span[2]')).click();
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/label[2]/span[1]')).click();
        browser.sleep(2000);

        console.log('ReisbijstandGezinFR: Vul einddatum reis in');
        var endDatePersonAssurance = dateFunctions.addTotalDays(14);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[1]/div/div[2]/div/div/label/app-new-datepicker/div/input')).sendKeys(endDatePersonAssurance);
        browser.sleep(2000);

        // Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[1]/div/div/label[1]/input')).click();
        browser.sleep(2000);

        console.log('ReisbijstandGezinFR: Valideer Prijs');
        element(by.className("vab__calculator__form__price")).getText().then(function (text) {
            expect(text).toBe('€ 543');
        });

    });

    it('ReisbijstandGezinFR: Vul gegevens in Medereiziger 1', function () {
        console.log('ReisbijstandGezinFR: Vul gegevens in Medereiziger 1');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[1]/div/div/label[1]/input')).sendKeys('TESTVAB1_First');
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[1]/div/div/label[2]/input')).sendKeys('TESTVAB1_Last');
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[1]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys('13/08/1991');
        browser.sleep(2000);

        // Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/a')).click();
        browser.sleep(2000);
    });

    it('ReisbijstandGezinFR: Vul gegevens in Medereiziger 2', function () {
        console.log('ReisbijstandGezinFR: Vul gegevens in Medereiziger 2');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/a')).click();
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[2]/div/div/label[1]/input')).click();
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[2]/div/div/label[1]/input')).sendKeys('TESTVAB2_First');
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[2]/div/div/label[2]/input')).sendKeys('TESTVAB2_Last');
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[2]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys('25/11/1985');
        browser.sleep(2000);

        console.log('ReisbijstandGezinFR: Valideer Prijs');
        element(by.className("vab__calculator__form__price")).getText().then(function (text) {
            expect(text).toBe('€ 627');
        });

        // Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[1]/div/div/label[1]/input')).click();

        browser.sleep(5000);
    });

    it('ReisjbijstandGezinFR: Bevestig gegevens correct', function () {
        console.log('ReisbijstandGezinFR: Bevestig gegevens correct');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/label/span[1]')).click();

    })

    it('ReisbijstandGezinFR: Klik op volgende knop', function () {
        console.log('ReisbijstandGezinFR: Klik op volgende knop');
        element(by.xpath("//span[@class='vab__button__label'][contains(text(),'Suivant')]")).click();
        browser.sleep(2000);

        browser.ignoreSynchronization = true;
    });

    it('ReisbijstandGezinFR: Valideer nieuwe pagina 2/4', function () {
        console.log('ReisbijstandGezinFR: Valideer nieuwe pagina 2/4');
        element(by.className("vab__fs--2 vab__ff--special-1")).getText().then(function (text) {
            expect(text).toBe('Étape 2 sur 4 : Données');
        });

        console.log('ReisbijstandGezinFR: Valideer Prijs');
        element(by.className("vab__calculator__form__price")).getText().then(function (text) {
            expect(text).toBe('€ 627');
        });
        browser.sleep(2000);
    });

    it('ReisbijstandGezinFR: Vul gegevens in', function () {
        console.log('ReisbijstandGezinFR: Vul gegevens in');
        element(by.id('PersonalDataViewModel_FirstName')).clear();
        element(by.id('PersonalDataViewModel_FirstName')).sendKeys('TESTVAB-FirstnameAAA');
        browser.sleep(2000);
        element(by.id('PersonalDataViewModel_LastName')).clear();
        element(by.id('PersonalDataViewModel_LastName')).sendKeys('TESTVAB-LastnameBBB');
        browser.sleep(2000);
        element(by.id('PersonalDataViewModel_BirthdateText')).clear();
        element(by.id('PersonalDataViewModel_BirthdateText')).sendKeys('13/10/1999');
        browser.sleep(2000);

    });

    it('ReisbijstandGezinFR: Vul adres in', function () {
        console.log('ReisbijstandGezinFR: Vul adres in');
        element(by.id('PersonalDataViewModel_AddressViewModel_ZipCode')).sendKeys('3201');
        element(by.id('PersonalDataViewModel_AddressViewModel_City')).sendKeys('Langdorp');
        element(by.id('PersonalDataViewModel_AddressViewModel_Street')).sendKeys('Blakerstraat');
        element(by.id('PersonalDataViewModel_AddressViewModel_Number')).sendKeys('50');
        browser.sleep(2000);
    });

    it('ReisbijstandGezinFR: Vul email in', function () {
        console.log('ReisbijstandGezinFR: Vul email in');
        element(by.id('PersonalDataViewModel_ContactDataViewModel_EmailAddress')).clear();
        element(by.id('PersonalDataViewModel_ContactDataViewModel_EmailAddress')).sendKeys('nvo@vab.be');
        element(by.id('PersonalDataViewModel_AddressViewModel_Number')).click();
        browser.sleep(2000);
    });

    it('ReisbijstandGezinFR: Klik checkbox algemene voorwaarden', function () {
        console.log('ReisbijstandGezinFR: Klik checkbox algemene voorwaarden');
        common.checkboxGeneralTerms.click();
        browser.sleep(2000);
    });

    it('ReisbijstandGezinFR: Klik op volgende knop', function () {
        console.log("ReisbijstandGezinFR: Klik op volgende knop");
        browser.sleep(2000);
        common.nextButton.click();
        browser.sleep(2000);
    });

    it('ReisbijstandGezinFR: Valideer nieuwe pagina 3/4', function () {
        console.log('ReisbijstandGezinFR: Valideer nieuwe pagina 3/4');
        element(by.className("vab__fs--2 vab__ff--special-1")).getText().then(function (text) {
            expect(text).toBe('Étape 3 sur 4 : Analyse des besoins');
        });

        console.log('ReisbijstandGezinFR: Valideer Prijs');
        element(by.className("vab__calculator__form__price")).getText().then(function (text) {
            expect(text).toBe('€ 627');
        });

    });

    it('ReisbijstandGezinFR: Vul behoefteanalyse pagina in', function () {
        console.log('ReisbijstandGezinFR: Vul behoefteanalyse pagina in');
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[3]/label[2]/span[2]')).click();
        browser.sleep(2000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[4]/label[2]/span[1]')).click();
        browser.sleep(2000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[5]/label[2]/span[1]')).click();
        browser.sleep(2000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[2]/span[2]')).click();
        browser.sleep(2000);
    });

    it('ReisbijstandGezinFR: Klik op toon resultaat', function () {
        console.log('ReisbijstandGezinFR: Klik op toon resultaat');
        element(by.id('submitBtn')).click();
        browser.sleep(4000);

    });

    it('ReisbijstandGezinFR: Valideer resultaat tekst', function () {
        console.log('ReisbijstandGezinFR: Valideer resultaat tekst');
        element(by.xpath('//*[@id="scrollToHere"]/p[1]')).getText().then(function (text) {
            expect(text).toBe(common.behoefteAnalyseFR);
        });
    });

    it('ReisbijstandGezinFR: Klik op volgende knop', function () {
        console.log('ReisbijstandGezinFR: Klik op volgende knop');
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[8]/a[2]')).click();
        browser.sleep(2000);
    });

    it('ReisbijstandGezinFR: Valideer nieuwe pagina 4/4', function () {
        console.log('ReisbijstandGezinFR: Valideer nieuwe pagina 4/4');
        element(by.className("vab__fs--2 vab__ff--special-1")).getText().then(function (text) {
            expect(text).toBe('Étape 4 sur 4 : Paiement');
        });

        console.log('ReisbijstandGezinFR: Valideer Prijs');
        element(by.className("vab__calculator__form__price")).getText().then(function (text) {
            expect(text).toBe('€ 627');
        });

    });

    it('ReisbijstandGezinFR: Vul vouchercode in', function () {
        console.log('ReisbijstandGezinFR: Vul vouchercode in');
        paymentFunctions.setVoucherCode(false);

        console.log('ReisbijstandGezinFR: Valideer Prijs');
        element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 569,6');
        });
    });
    if (common.payment) {
        it('MultipakketSingleNL: Betaalstap selecteer BC', function () {
            paymentFunctions.bankContactPayment();
        });
    };
});