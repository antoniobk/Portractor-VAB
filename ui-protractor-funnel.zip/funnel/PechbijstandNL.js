var Common = require('./VABcommon/common.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');

describe("PechbijstandNL: Buy a product: Pechbijstand (NL)\n", function () {
	var common = new Common();
	var applicationURL = common.applicationURL;
	var EC = protractor.ExpectedConditions;

	

	it('PechbijstandNL: Open browser & accepteer cookies', function () {
		console.log('PechbijstandNL: Open browser & accepteer cookies');
		browser.waitForAngularEnabled(false);
		browser.get(applicationURL + '/nl/pech-en-reisbijstand/auto-en-motor');
		browser.wait(EC.visibilityOf(common.cookie), 30000, "Timeout of VisibilityOf: Bijstand auto en motor");
		common.cookie.click();
	});

	it('PechbijstandNL: Valideer prijs', function () {
		console.log('PechbijstandNL: Valideer prijs');
		var ele = element(by.xpath("/html/body/section[2]/div"));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Bijstand auto en motor");

		var myElement = element(by.xpath('/html/body/section[3]/div/header/h1'));
		expect(myElement.isPresent()).toBe(true);

		element(by.xpath('/html/body/section[3]/div/header/h1')).getText().then(function (PechTitel) {
			expect(PechTitel).toBe(common.pechbijstandTitelNL);
		});
	});

	it('PechbijstandNL: Navigeer naar pagina', function () {
		console.log('PechbijstandNL: Klikken op bestel nu');
		element(by.xpath("/html/body/section[5]/div/ul/li/ul/li[1]/div/div[4]/a")).click();
		browser.sleep(2000);
	});

	it('PechbijstandNL: Valideer prijs', function () {
		console.log("PechbijstandNL: Valideer prijs");
		var ele = element(by.className("vab__calculator__form__theHeading"));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Pechbijstand");

		// Mousemove zorgt ervoor dat Firefox scherm out of bounds is en test faalt.
		browser.actions().mouseMove(element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/div/a/span'))).perform();
	    browser.sleep(5000);

		console.log('PechbijstandNL: Valideer prijs');
		element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 128');
		});
	});

	it('PechbijstandNL: Voeg voertuig toe', function () {
		console.log('PechbijstandNL: Voeg voertuig toe');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[1]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
        browser.sleep(2000);

		console.log('PechbijstandNL: Valideer prijs');
		element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 238');
		});

		console.log('PechbijstandNL: Voeg voertuig toe');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[1]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);

		console.log('PechbijstandNL: Valideer prijs');
		element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 348');
		});
	});

	it('PechbijstandNL: Voeg vervangwagen toe', function () {
		console.log('PechbijstandNL: Voeg vervangwagen toe');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[2]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);

		console.log('PechbijstandNL: Valideer prijs');
		element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 407');
		});
	});

	it('PechbijstandNL: Voeg vervangwagen toe', function () {
		console.log('PechbijstandNL: Voeg vervangwagen toe');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[2]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
		browser.sleep(2000);

		console.log('PechbijstandNL: Valideer prijs');
		element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 466');
		});
	});

	it('PechbijstandNL: Klik op bestel online knop', function () {
		console.log('PechbijstandNL: Klik op bestel online knop');
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/div/a/span')).click();
		browser.sleep(2000);
	});

	it('PechbijstandNL: Valideer nieuwe pagina 1/3', function () {
		console.log('PechbijstandNL: Valideer nieuwe pagina 1/3');
		var ele = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[3]/div/div/label[2]/span[2]'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 1 van 3: Jouw VAB-Pechbijstand");
		browser.sleep(2000);

		console.log('PechbijstandNL: Valideer prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 466');
		});
	});

	it('PechbijstandNL: Vul nummerplaten in', function () {
		console.log('PechbijstandNL: Vul nummerplaten in');
		console.log('PechbijstandNL: Nummerplaat 1');
		element(by.xpath("/html/body/section[2]/div/app-root/app-dynamic-component/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[1]/div/div/label[1]/input")).sendKeys('1-VAB-001');
		browser.sleep(2000);

		console.log('PechbijstandNL: Nummerplaat 2');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[2]/div/div/label[1]/input')).sendKeys('1-VAB-002');
		browser.sleep(2000);

		console.log('PechbijstandNL: Nummerplaat 3');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[3]/div/div/label[1]/input')).sendKeys('MYVAB');
		browser.sleep(2000);

		console.log('PechbijstandNL: Valideer prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 466');
		});
	});

	it('PechbijstandNL: Klik op volgende knop', function () {
		console.log('PechbijstandNL: Klik op volgende knop');
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/div[1]/a/span')).click();
		browser.sleep(2000);
	});

	it('PechbijstandNL: Valideer nieuwe pagina 2/3', function () {
		console.log('PechbijstandNL: Valideer nieuwe pagina 2/3');
		var ele = element(by.xpath('//*[@id="thefunnelform"]/div/div[2]/div/h2'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 2 van 3: Gegevens");

		console.log('PechbijstandNL: Valideer prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 466');
		});
	});

	it('PechbijstandNL: Vul gegevens in', function () {
		console.log('PechbijstandNL: Vul gegevens in');
		common.firstName.sendKeys(common.userFirstName);
		common.lastName.sendKeys(common.userLastName);
		common.datepicker.sendKeys(common.userBirthDate);
		browser.sleep(2000);
	});

	it('PechbijstandNL: Vul adres in', function () {
		console.log('PechbijstandNL: Vul adres in');
		common.zipcode.sendKeys(common.userZipcode);
		common.city.sendKeys(common.userCity);
		common.street.sendKeys(common.userStreet);
		common.houseNumber.sendKeys(common.userHouseNumber);
		browser.sleep(2000);
	});

	it('PechbijstandNL: Vul email in', function () {
		console.log('PechbijstandNL: Vul email in');
		common.email.sendKeys(common.userEmail);
		browser.sleep(2000);
	});

	it('PechbijstandNL: Klik checkbox algemene voorwaarden', function () {
		console.log('PechbijstandNL: Klik checkbox algemene voorwaarden');
		common.checkboxGeneralTerms.click();
	});

	it('PechbijstandNL: Klik checkbox domiciliëring', function () {
		console.log('PechbijstandNL: Klik checkbox domiciliëring');
		element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/label[2]/span[1]')).click();
		browser.sleep(2000);
	});

	it('PechbijstandNL: Vul IBAN in', function () {
		console.log('PechbijstandNL: Vul IBAN in');
		common.IBAN.sendKeys(common.userValidIBAN);
		browser.sleep(2000);
	});

	it('PechbijstandNL: Klik op volgende knop', function () {
		console.log('PechbijstandNL: Klik op volgende knop');
		common.nextButton.click();
		browser.sleep(2000);
	});

	it('PechbijstandNL: Valideer nieuwe pagina 3/3', function () {
		console.log('PechbijstandNL: Valideer nieuwe pagina 3/3');
		var ele = element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/div/form/ul[2]/li[4]/label/div/span[2]'));
		browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 3 van 3: Betaling");

		console.log('PechbijstandNL: Valideer prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			expect(defaultPricing).toBe('€ 451');
			browser.sleep(2000);
		});
	});

	it('PechbijstandNL: Vul vouchercode in', function () {
        console.log('PechbijstandNL: Vul vouchercode in');
        paymentFunctions.setVoucherCode(true);

		console.log('PechbijstandNL: Valideer Prijs');
		element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
			// TW-266 tijdelijke aanpassing in afwachting van nauwkeurigere prijs van PECHVVW-001 door KLA
			expect(defaultPricing).toBe('€ 416,8');
		});
	});

	if (common.payment) {
		it('PechbijstandNL: Betaalstap selecteer Bankcontact', function () {
            paymentFunctions.bankContactPayment();
		});
	}
});


