var Common = require('./VABcommon/common.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
describe('FietsbijstandSingleNL: Buy a product: FietsbijstandSingle', function () {
    var common = new Common();
    var applicationURL = common.applicationURL;
    var EC = protractor.ExpectedConditions;

    it('FietsbijstandSingleNL: Open browser & accepteer cookies', function () {
        console.log('FietsbijstandSingleNL: Open browser & accepteer cookies');
        browser.get(applicationURL + '/nl/pech-en-reisbijstand/fiets/fietsbijstand');
        browser.sleep(2000);
        common.cookie.click();
        browser.sleep(2000);
    });

    it('FietsbijstandSingleNL: Valideer prijs fietsbijstand', function () {
        console.log('FietsbijstandSingleNL: Valideer prijs fietsbijstand');
        var ele = element(by.className("vab__calculator__form__theHeading"));
        browser.wait(EC.visibilityOf(ele), 50000, "Timeout of VisibilityOf: Fietsbijstand homepage");
        
        element(by.xpath("//p[@itemprop='price']")).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 45');
        });
    });

    it('FietsbijstandSingleNL: Klik op volgende knop', function () {
        console.log('FietsbijstandSingleNL: Klik op volgende knop');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/a/span')).click();
        browser.sleep(2000);
    });

    it('FietsbijstandSingleNL: Valideer nieuwe pagina 1/3', function () {
        browser.waitForAngularEnabled(false);
        console.log('FietsbijstandSingleNL: Valideer nieuwe pagina 1/3');
        var ele = element(by.className("h1 vab__fs--2 vab__ff--special-1"));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout reached");

        element(by.xpath('/html/body/section[2]/div/app-root/app-dynamic-component/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[1]/div[1]/h1')).getText().then(function (text) {
            expect(text).toBe(common.fietsbijstandTitelNL);
        });
    });

    it('FietsbijstandSingleNL: Valideer prijs', function () {
        console.log('FietsbijstandSingleNL: Valideer prijs');

        element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 45');
        });
    });

    it('FietsbijstandSingleNL: Vul details in persoon 1', function () {
        console.log('FietsbijstandSingleNL: Ingave gegevens van persoon 1');
        element(by.xpath("//input[@itemprop='firstName']")).sendKeys(common.userFirstName);
        element(by.xpath("//input[@itemprop='lastName']")).sendKeys(common.userLastName);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[5]/div[1]/app-person/div/div[1]/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);
        
        // Validation needs to have focus
        element(by.xpath("//input[@itemprop='lastName']")).click();
        browser.sleep(2000);


    });

    it('FietsbijstandSingleNL: Klik op volgende knop', function () {
        console.log('FietsbijstandSingleNL: Klik op volgende knop');
        element(by.xpath("/html/body/section[2]/div/app-root/app-dynamic-component/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/div[1]/a")).click();
        browser.sleep(2000);
    });

    it('FietsbijstandSingleNL: Valideer nieuwe pagina 2/3', function () {
        console.log('FietsbijstandSingleNL: Valideer nieuwe pagina 2/3');
        browser.waitForAngularEnabled(false);

        var ele = element(by.className("vab__fs--2 vab__ff--special-1"));
        browser.wait(EC.visibilityOf(ele), 40000, "Timeout reached");

        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div[1]/div[1]/p')).getText().then(function (text) {
            expect(text).toBe('Stap 2 van 3: Gegevens');

        });
    });

    it('FietsbijstandSingleNL: Valideer prijs', function () {
        console.log('FietsbijstandSingleNL: Valideer prijs');
        element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 45');
        });
    });

    it('FietsbijstandSingleNL: Vul adres in persoon 1', function () {
        console.log('FietsbijstandSingleNL: Vul adres in persoon 1');

        element(by.xpath("//input[@name='PersonalDataViewModel.AddressViewModel.ZipCode']")).sendKeys(common.userZipcode);
        element(by.xpath("//input[@name='PersonalDataViewModel.AddressViewModel.City']")).sendKeys(common.userCity);
        element(by.xpath("//input[@name='PersonalDataViewModel.AddressViewModel.Street']")).sendKeys(common.userStreet);
        element(by.xpath("//input[@name='PersonalDataViewModel.AddressViewModel.Number']")).sendKeys(common.userHouseNumber);

        // Validation needs to have focus
        element(by.id('PersonalDataViewModel_AddressViewModel_MailBox')).click();
        browser.sleep(2000);
    });

    it('FietsbijstandSingleNL: Vul email in persoon 1', function () {
        console.log('FietsbijstandSingleNL: Vul email in persoon 1');
        element(by.id('PersonalDataViewModel_ContactDataViewModel_EmailAddress')).sendKeys(common.userEmail);

        // Validation needs to have focus
        element(by.id('PersonalDataViewModel_AddressViewModel_MailBox')).click();
        browser.sleep(2000);
    });

    it('FietsbijstandSingleNL: Klik op checkbox', function () {
        console.log('FietsbijstandSingleNL: Klik op checkbox');
        element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/label[1]/span[1]')).click();
        browser.sleep(2000);
    });

    it('FietsbijstandSingleNL: Klik op volgende knop', function () {
        console.log('FietsbijstandSingleNL: Klik op volgende knop');
        element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/div/button[2]/span')).click();
        browser.sleep(2000);
    });

    it('FietsbijstandSingleNL: Valideer nieuwe pagina 3/3', function () {
        console.log('FietsbijstandSingleNL: Valideer nieuwe pagina 3/3');
        var ele = element(by.xpath("/html/body/section[2]/div/div/div/div/div/div[1]/div/div/div/form"));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout reached");

        element(by.className("vab__fs--2 vab__ff--special-1")).getText().then(function (text) {
            expect(text).toBe('Stap 3 van 3: Betaling');
        });
    });

    it('FietsbijstandSingleNL: Valideer prijs', function () {
        console.log('FietsbijstandSingleNL: Valideer prijs');
        element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 45');
        });
    });
    if (common.payment) {
        it('Betaalstap selecteer MasterCard', function () {
            paymentFunctions.masterCardPayment();
        });
    };
});