var Common = require('./VABCommon/common.js');
var dateFunctions = require('./VABCommon/dateFunctions.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');
describe("TijdelijeReisbijstandBagageNL: Tijdelijke reisverzekering: Annulatie", function () {
	var common = new Common();
	var URL = common.applicationURL;
	var EC = protractor.ExpectedConditions;
	var vehiclePriceFormatted;

	it('TijdelijeReisbijstandBagageNL: Open browser & accepteer cookies', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Open browser & accepteer cookies");
		browser.get(URL + '/nl/pech-en-reisbijstand/bijstand-op-reis/tijdelijke-reisbijstand/reisbijstand-en-bagage');
		browser.sleep(2000);
		common.cookie.click();
		browser.sleep(5000);
		browser.waitForAngularEnabled(false);
	});


	it('TijdelijkeReisbijstandBagageNL: Vul start datum in', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Vul start datum in");
		startDate = dateFunctions.addTotalDays(1);
		console.log('TijdelijkeReisbijstandBagageNL: startdate: ' + startDate);
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[2]/div/label/div[2]/app-new-datepicker/div/input')).sendKeys(startDate);

		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/p')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeReisbijstandBagageNL: Vul eind datum in', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Vul eind datum in");
		endDate = dateFunctions.addTotalDaysReferenceDate(startDate, 8);
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[3]/div/label/div[2]/app-new-datepicker/div/input')).sendKeys(endDate);

		// Wijzig focus door validaties
		element(by.className('vab__calculator__form__theHeading')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeReisbijstandBagageNL: Voeg personen toe', function () {
		console.log("TijdelijkeReisbijstandBagegeNL: Voeg personen toe");
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[1]/app-stepper-option/div/label/div[2]/app-plus-minus-input/div/div[3]/span')).click();
	});


	it('TijdelijkeReisbijstandBagageNL: Valideer prijs ', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Valideer prijs");
		browser.sleep(2000);
		element(by.className("vab__calculator__form__price vab__heading--1")).getText().then(function (text) {
			expect(text).toBe('€ 58,5');
		});
		browser.sleep(5000);

	});

	it('TijdelijkeReisbijstandBagageNL: Voeg personen', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Voeg personen toe");
		var personPrice = 58.5;
		var addPriceVehicle = 35.1;

		for (i = 0; i < 2; i++) {
			element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
			browser.sleep(2000);

			element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
				console.log('TijdelijkeReisbijstandBagageNL: Valideer prijs');
				personPrice = personPrice + addPriceVehicle;
				vehiclePriceFormatted = personPrice.toString().replace(".", ",");
				expect(defaultPricing).toBe('€ ' + vehiclePriceFormatted);

				console.log('TijdelijkeReisbijstandBagageNL: Vehicle prijs = ' + personPrice);
			});
		}
	});

	it('TijdelijkeReisbijstandBagageNL: Klik op bestel online', function () {
		element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/div/a')).click();
		browser.sleep(3000);
	});

	it('TijdelijkeReisbijstandBagageNL: Valideer nieuwe pagina', function () {
		console.log('TijdelijkeReisbijstandBagageNL: Valideer nieuwe pagina');
		var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 40000, "Timeout of VisibilityOf: Stap 1 van 4: Jouw Tijdelijke Reisbijstand + Bagage");
	});

	it('TijdelijkeReisbijstandBagageNL: Valideer prijs', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Valideer prijs");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).getText().then(function (price) {
			expect(price).toBe('€ ' + vehiclePriceFormatted)
		});
	});


	it("TijdelijkeReisbijstandBagageNL: Valideer start datum", function () {
		console.log("TijdelijkeReisbijstandBagageNL: Valideer start datum: " + startDate);
		var inputStartDatum = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[1]/li/div[2]/div/app-contract-option/div/div/div/div[1]/div[1]/div/label/app-new-datepicker/div/input'));
		expect(inputStartDatum.getAttribute('value')).toEqual(startDate);
	});

	it("TijdelijkeReisbijstandBagageNL: Valideer eind datum", function () {
		console.log("TijdelijkeReisbijstandBagageNL: Valideer eind datum: " + endDate);
		var inputEindDatum = element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[1]/li/div[2]/div/app-contract-option/div/div/div/div[1]/div[2]/div/label/app-new-datepicker/div/input'));
		expect(inputEindDatum.getAttribute('value')).toEqual(endDate);
	});

	it('TijdelijkeReisbijstandBagageNL: Vul gegevens personen in', function () {
		for (i = 1; i <= 2; i++) {

			console.log("TijdelijkeReisbijstandBagageNL: Vul gegevens in persoon", + i + " in");
			element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[' + i + ']/div/div/label[1]/input')).sendKeys(common.userFirstName);
			element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[' + i + ']/div/div/label[2]/input')).sendKeys(common.userLastName);
			element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[' + i + ']/div/div/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);

			// Wijzig focus door validaties
			element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[1]/div/div/label[1]/input')).click();
			browser.sleep(2000);

		}
	});
	it('TijdelijkeReisbijstandBagageNL: Voeg medereiziger toe', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Voeg medereiziger toe");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[2]/a/div')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeReisbijstandBagageNL: Vul gegevens persoon 3 in', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Vul gegevens persoon 3 in");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[3]/div/div/label[1]/input')).sendKeys(common.userFirstName + "3");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[3]/div/div/label[2]/input')).sendKeys(common.userLastName + "3");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[3]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);
		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[2]/div/div/label[1]/input')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeReisbijstandBagageNL: Valideer prijs', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Valideer prijs");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).getText().then(function (price) {
			expect(price).toBe('€ 157,95')
		});
	});



	it('TijdelijkeReisbijstandBagageNL: Vul nummerplaten', function () {

		for (i = 1; i <= 2; i++) {
			console.log("TijdelijkeReisbijstandBagageNL: Vul nummerplaat " + i + " in");
			let rdnNummerplaat = Math.random().toString(36).substr(2, 6);
			element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[4]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[' + i + ']/div/div/label/input')).sendKeys(rdnNummerplaat);
			// Wijzig focus door validaties
			element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[2]/div/div/label[1]/input')).click();
			browser.sleep(2000);

		}

	});

	it('TijdelijkeReisbijstandBagageNL: Voeg een derde voertuig toe', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Voeg een derde voertuig toe");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[4]/li/div[2]/div/app-vehicles-option/div[2]/a')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeReisbijstandBagageNL: vul nummerplaat voertuig drie in', function () {
		console.log("TijdelijkeReisbijstandBagageNL: vul nummerplaat voertuig drie in");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[4]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[3]/div/div/label/input')).sendKeys("kyq8943")
		// Wijzig focus door validaties
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[2]/div/div/label[1]/input')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeReisbijstandBagageNL: Valideer prijs', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Valideer prijs");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).getText().then(function (price) {
			expect(price).toBe('€ 193,05')
		});
	});

	it('TijdelijkeReisbijstandBagageNL: Klik op volgende knop', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Klik op volgende knop");
		element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/div[1]/a/span')).click();
		browser.sleep(3000);
	});

	it('TijdelijkeReisbijstandBagageNL: Valideer nieuwe pagina', function () {
		console.log('TijdelijkeReisbijstandBagageNL: Valideer nieuwe pagina');
		var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 40000, "Timeout of VisibilityOf: Stap 2 van 4: Gegevens");
	});

	it('TijdelijkeReisbijstandBagageNL: Vul adres in', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Vul adres in");
		common.zipcode.sendKeys(common.userZipcode);
		common.city.sendKeys(common.userCity);
		common.street.sendKeys(common.userStreet);
		common.houseNumber.sendKeys(common.userHouseNumber);

	});

	it('TijdelijkeReisbijstandBagageNL: Vul email in', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Vul email in");
		common.email.sendKeys(common.userEmail);
		browser.sleep(2000);
	});

	it('TijdelijkeReisbijstandBagageNL: Klik checkbox algemene voorwaarden', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Klik checkbox algemene voorwaarden");
		common.checkbox.click();
	});

	it('TijdelijkeReisbijstandBagageNL: Klik op volgende knop', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Klik op volgende knop");
		browser.sleep(2000);
		common.nextButton.click();
		browser.sleep(2000);
	});

	it('TijdelijkeReisbijstandBagageNL: Valideer nieuwe pagina', function () {
		console.log('TijdelijkeReisbijstandBagageNL: Valideer nieuwe pagina');
		var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 40000, "Timeout of VisibilityOf: Stap 3 van 4: Behoefteanalyse");
	});



	it('TijdelijkeReisbijstandBagageNL: Vul behoefteanalyse pagina in', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Vul behoefteanalyse pagina in");
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[3]/label[1]/span[2]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[4]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[5]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[1]/span[2]')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeReisbijstandBagageNL: Klik op toon resultaat', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Klik op toon resultaat");
		element(by.id('submitBtn')).click();
		browser.sleep(2000);
	});

	it('TijdelijkeReisbijstandBagageNL: Valideer resultaat tekst', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Valideer resultaat tekst");
		element(by.xpath('//*[@id="scrollToHere"]')).getText().then(function (text) {
			expect(text).toBe(common.befoefteAnalyseTijdelijkeBagageNL);
		});
	});

	it('TijdelijkeReisbijstandBagageNL: Klik op volgende knop', function () {
		console.log("TijdelijkeReisbijstandBagageNL: Klik op volgende knop");
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[8]/a[2]/span')).click();
		browser.sleep(4000);
	});

	it('TijdelijkeReisbijstandBagageNL: Valideer nieuwe pagina', function () {
		console.log('TijdelijkeReisbijstandBagageNL: Valideer nieuwe pagina');
		var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
		browser.wait(EC.visibilityOf(ele), 40000, "Timeout of VisibilityOf: Stap 4 van 4: Betaling");
	});

	if (common.applicationURL === 'https://acc.vab.be') {
		it('Betaalstap selecteer MasterCard', function () {
			paymentFunctions.visaPayment();
		});
	};
});