var Common = require('./VABCommon/common.js');
var dateFunctions = require('./VABCommon/dateFunctions.js');
var paymentFunctions = require('./VABCommon/paymentFunctions.js');

describe("MultipakketSingleNL: Buy a product: Multipakket Single", function () {
    var common = new Common();
    var applicationURL = common.applicationURL;
    var EC = protractor.ExpectedConditions;

    it('MultipakketSingleNL: Open browser & accepteer cookies', function () {
        console.log('MultipakketSingleNL: Open browser & accepteer cookies');
        browser.get(applicationURL + '/nl/pech-en-reisbijstand/bijstand-op-reis/multipakket');
        browser.sleep(2000);
        common.cookie.click();
        browser.sleep(2000);
        browser.waitForAngularEnabled(false);
    });

    it('MultipakketSingleNL: Valideer prijs', function () {
        console.log('MultipakketSingleNL: Valideer prijs');
        var ele = element(by.className("vab__intro__title vab__heading--2"));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Bijstand op reis");

        element(by.className('vab__calculator__form__theHeading')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('Bereken je tarief');
        });

        console.log('MultipakketSingleNL: Valideer prijs');
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 345');
        });
    });

    it('MultipakketSingleNL: Voeg extra voertuig toe', function () {
        console.log('MultipakketSingleNL: Voeg extra voertuig toe');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[1]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
        browser.sleep(2000);
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 455');
        });
    });

    it('MultipakketSingleNL: Voeg extra vervangwagen toe', function () {
        console.log('MultipakketSingleNL: Voeg extra vervangwagen toe');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[2]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
        browser.sleep(2000);
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 539');
        });

        console.log('MultipakketSingleNL: Voeg extra vervangwagen toe');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[2]/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
        browser.sleep(2000);
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 623');
        });
    });

    it('MultipakketSingleNL: Voeg optie camper toe', function () {
        console.log('MultipakketSingleNL: Voeg optie camper toe');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[3]/div/label/div/div/span')).click();
        browser.sleep(2000);
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 717');
        });
    });

    it('MultipakketSingleNL: Voeg optie annulatieverzekering toe', function () {
        console.log('MultipakketSingleNL: Voeg optie annulatieverzekering toe');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div[5]/div/label/div/div/span')).click();
        browser.sleep(2000);
        element(by.className('vab__calculator__form__price vab__heading--1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 793');
        });
    });

    it('MultipakketSingleNL: Klik op volgende knop', function () {
        console.log('MultipakketSingleNL: Klik op volgende knop');
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[4]/div/a/span')).click();
        browser.sleep(2000);
    });


    it('MultipakketSingleNL: Valideer nieuwe pagina 1/4', function () {
        console.log('MultipakketSingleNL: Valideer nieuwe pagina 1/4');
        var ele = element(by.className('h1 vab__fs--2 vab__ff--special-1'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 1 van 4: Jouw VAB-Annulatieverzekering");

        element(by.className('h1 vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('Stap 1 van 4: Jouw VAB-Multipakket');
        });

        console.log('MultipakketSingleNL: Valideer prijs');
        element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 793');
        });
    });

    it('MultipakketSingleNL: Vul gegevens in van persoon 1', function () {
        console.log('MultipakketSingleNL: Vul gegevens in van persoon 1');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[1]/div/div/label[1]/input')).sendKeys(common.userFirstName);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[1]/div/div/label[2]/input')).sendKeys(common.userLastName);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[2]/li/div[2]/div/app-persons-option/div/div[4]/div/app-person[1]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);

        // Wijzig focus door validaties
        console.log('MultipakketSingleNL: Click to lose focus');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
        browser.sleep(2000);
    });


    it('MultipakketSingleNL: Vul langer verblijf in', function () {
        console.log('MultipakketSingleNL: Vul langer verblijf in');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-stay-option/div/label[1]/span[1]')).click();
        browser.sleep(2000);

        console.log('MultipakketSingleNL: Vul begindatum langer verblijf in');
        var startDate = dateFunctions.getFutureDate(1, 2);

        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-stay-option/div/div/div[1]/div/div[1]/div/div/label/app-new-datepicker/div/input')).sendKeys(startDate);
        browser.sleep(2000);

        // Validation needs to have focus	
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
        browser.sleep(2000);

        console.log('MultipakketSingleNL: Vul einddatum langer verblijf in');
        //Minstens 120+30 dagen toevoegen              
        var endDate = dateFunctions.addTotalDaysReferenceDate(startDate, 151);

        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-stay-option/div/div/div[1]/div/div[2]/div/div/label/app-new-datepicker/div/input')).sendKeys(endDate);
        browser.sleep(2000);

        // Validation needs to have focus	
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[2]/div/div/div/app-sticky-scroll-element/div/app-product-funnel-calculator/div/div/div[3]/span')).click();
        browser.sleep(2000);

        element(by.className("vab__calculator__form__price")).getText().then(function (text) {
            expect(text).toBe('€ 889');
        });
    });

    it('MultipakketSingleNL: Vul nummerplaten in', function () {
        console.log('MultipakketSingleNL: Vul nummerplaten in');
        console.log('VakantiepakketGezinFR: Nummerplaat 1');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[5]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[1]/div/div/label[1]/input')).sendKeys('NOTABOAT');

        console.log('VakantiepakketGezinFR: Nummerplaat 2');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[5]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle[2]/div/div/label[1]/input')).sendKeys('NOTABOAT2');
        browser.sleep(2000);
    });


    it('MultipakketSingleNL: Voeg medereiziger toe', function () {
        console.log('MultipakketSingleNL: Voeg medereiziger toe');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/label[1]/span[1]')).click();
        browser.sleep(2000);

        console.log('MultipakketSingleNL: Klik op wereldwijd');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/label[2]/span[1]')).click();
        browser.sleep(2000);

        console.log('MultipakketSingleNL: Vul einddatum reis in');
        var endDate = dateFunctions.addTotalDays(21);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[1]/div/div[2]/div/div/label/app-new-datepicker/div/input')).sendKeys(endDate);
        browser.sleep(2000);

        // Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler/div/div/label[1]/input')).click();
        browser.sleep(2000);

        console.log('MultipakketSingleNL: Valideer Prijs');
        element(by.className("vab__calculator__form__price")).getText().then(function (text) {
            expect(text).toBe('€ 1015');
        });
    });

    it('MultipakketSingleNL: Medereiziger 1', function () {
        console.log('MultipakketSingleNL: Medereiziger 1');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler/div/div/label[1]/input')).sendKeys('TESTVAB1_First');
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler/div/div/label[2]/input')).sendKeys('TESTVAB1_Last');
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler/div/div/label[3]/app-new-datepicker/div/input')).sendKeys('13/08/1991');
        browser.sleep(2000);

        // Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/a')).click();
        browser.sleep(2000);

        console.log('MultipakketSingleNL: Valideer Prijs');
        element(by.className("vab__calculator__form__price")).getText().then(function (text) {
            expect(text).toBe('€ 1015');
        });
    });

    it('MultipakketSingleNL: Medereiziger 2', function () {
        console.log('MultipakketSingleNL: Medereiziger 2');
        console.log('MultipakketSingleNL: Voeg medereiziger toe');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/a')).click();
        browser.sleep(2000);

        console.log('MultipakketSingleNL: Vul gegevens in');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[2]/div/div/label[1]/input')).click();
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[2]/div/div/label[1]/input')).sendKeys('TESTVAB2_First');
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[2]/div/div/label[2]/input')).sendKeys('TESTVAB2_Last');
        browser.sleep(2000);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[2]/div/div/label[3]/app-new-datepicker/div/input')).sendKeys('25/11/1985');
        browser.sleep(2000);

        //Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[6]/li/div[2]/div/app-travelers-option/div/div/div[2]/div/app-traveler[2]/div/div/label[2]/input')).click();
        browser.sleep(2000);

        console.log('MultipakketSingleNL: Valideer Prijs');
        element(by.className("vab__calculator__form__price")).getText().then(function (text) {
            expect(text).toBe('€ 1141');
        });
    });

    it('MultipakketSingle: Bevestig correcte gegevens', function () {
        console.log('MultipakketSingleNL: Bevestig correcte gegevens');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[3]/label/span[1]')).click();
    })
    it('MultipakketSingleNL: Klik op volgende knop', function () {
        console.log('MultipakketSingleNL:  Klik op volgende knop');
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/div[4]/div[1]/a')).click();
        browser.sleep(4000);

        // browser.ignoreSynchronization = true;
    });

    it('MultipakketSingleNL: Valideer nieuwe pagina 2/4', function () {
        console.log('MultipakketSingleNL:  Valideer nieuwe pagina 2/4');
        var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 2 van 4: Gegevens");

        element(by.className('vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('Stap 2 van 4: Gegevens');
        });

        console.log('MultipakketSingleNL: Valideer Prijs');
        element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 1141');
        });
    });

    it('MultipakketSingleNL: Vul adres gegevens in', function () {
        console.log('MultipakketSingleNL: Vul adres gegevens in');
        common.zipcode.sendKeys(common.userZipcode);
        common.city.sendKeys(common.userCity);
        common.street.sendKeys(common.userStreet);
        common.houseNumber.sendKeys(common.userHouseNumber);
    });

    it('MultipakketSingleNL: Vul email in', function () {
        console.log('MultipakketSingleNL: Vul email in');
        common.email.sendKeys(common.userEmail);
        browser.sleep(2000);
    });

    it('MultipakketSingleNL: Klik checkbox algemene voorwaarden', function () {
        console.log('MultipakketSingleNL: Klik checkbox algemene voorwaarden');
        element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/label[1]/span[1]')).click();
        browser.sleep(2000);
    });

    it('MultipakketSingleNL: Volgende knop', function () {
        console.log('MultipakketSingleNL: Volgende knop');
        element(by.xpath('//*[@id="thefunnelform"]/div/div[3]/div[2]/button[2]')).click();;
        browser.sleep(2000);
    });

    it('MultipakketSingleNL: Valideer nieuwe pagina 3/4', function () {
        console.log('MultipakketSingleNL: Valideer nieuwe pagina 3/4');
        var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 3 van 4");

        element(by.className('vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('Stap 3 van 4: Behoefteanalyse');
        });

        console.log('MultipakketSingleNL: Valideer Prijs');
        element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 1141');
        });
    });

    it('MultipakketSingleNL: Vul behoefteanalyse pagina in', function () {
        console.log('MultipakketSingleNL: Vul behoefteanalyse pagina in');
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[3]/label[1]/span[2]')).click();
        browser.sleep(2000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[4]/label[2]/span[1]')).click();
        browser.sleep(2000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[5]/label[2]/span[1]')).click();
        browser.sleep(2000);
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[1]/span[2]')).click();
        browser.sleep(4000);
    });

    it('MultipakketSingleNL: Klik op toon resultaat', function () {
        console.log('MultipakketSingleNL: Klik op toon resultaat');
        var submitBtn = element(by.id('submitBtn'))
        browser.wait(EC.visibilityOf(submitBtn), 30000, "Timeout of VisibilityOf: Stap 4 van 4");
        submitBtn.click();
        browser.sleep(4000);
    });

    it('MultipakketSingleNL: Valideer resultaat tekst', function () {
        console.log('MultipakketSingleNL: Valideer resultaat tekst');
        element(by.xpath('//*[@id="scrollToHere"]/p[1]')).getText().then(function (text) {
            expect(text).toBe(common.behoefteAnalyseTijdelijkeNL);
        });
    });

    it('MultipakketSingleNL: Klik op volgende knop', function () {
        console.log('MultipakketSingleNL: Klik op volgende knop');
        element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[8]/a[2]')).click();
        browser.sleep(5000);
    });

    it('MultipakketSingleNL: Valideer nieuwe pagina 4/4', function () {
        console.log('MultipakketSingleNL: Valideer nieuwe pagina 4/4');
        var ele = element(by.className('vab__fs--2 vab__ff--special-1'));
        browser.wait(EC.visibilityOf(ele), 30000, "Timeout of VisibilityOf: Stap 4 van 4");

        element(by.className('vab__fs--2 vab__ff--special-1')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('Stap 4 van 4: Betaling');
        });

        console.log('MultipakketSingleNL: Valideer Prijs');
        element(by.className('vab__calculator__form__price')).getText().then(function (defaultPricing) {
            expect(defaultPricing).toBe('€ 1141');

        });
    });
    
    if (common.payment) {
        it('MultipakketSingleNL: Betaalstap selecteer BC', function () {
            paymentFunctions.bankContactPayment();
        });
    };
});

