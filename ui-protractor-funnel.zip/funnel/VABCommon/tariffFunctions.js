var Common = require('./common.js');

var TariffFunctions = function(){
    var EC = protractor.ExpectedConditions;
    var common = new Common();

    var totalPrice;
    var defaultMinPriceVehicle=25;
    var defaultPriceVehicle=3.9;
    var defaultPrice=40;

    this.calculateQuotient = function(dividend, divisor){
		console.log("TariffFunctions: calculateQuotient");
        quotient = ~~(dividend/divisor);
        return quotient;
    };

	this.calculatePriceTempHolidayPacket = function(totalTravelPrice,totalDays,totalMonths,totalPersons,totalVehicles) {
		console.log("TariffFunctions: calculatePriceTempHolidayPacket");
		console.log("calculatePriceTempHolidayPacket: Calculate totals = " + totalTravelPrice);
        startPrice = totalTravelPrice * 7 / 100;
        console.log("calculatePriceTempHolidayPacket: StartPrice = " + startPrice);

        if (startPrice < defaultPrice){
            console.log("calculatePriceTempHolidayPacket: StartPrice is less than defaultprice");
            totalPrice =  totalPersons * defaultPrice;
        }else if (startPrice > defaultPrice){
            console.log("calculatePriceTempHolidayPacket: StartPrice is equal or more than defaultprice");
            calculatePersonsStaticPrice = this.calculateQuotient(startPrice,defaultPrice);

            if (totalPersons>calculatePersonsStaticPrice){
                console.log("calculatePriceTempHolidayPacket: Total persons is more than quotient persons static price");
                totalPrice = totalPersons * defaultPrice;;
            }else{
                console.log("calculatePriceTempHolidayPacket: Startprice is used for totalprice");
                totalPrice=startPrice;
            }
        }

        if(totalVehicles > 0){
            console.log("calculatePriceTempHolidayPacket: Calculate price vehicles");
            totalPriceVehicles = (totalDays+1)*totalVehicles*defaultPriceVehicle;
    
            if (totalPriceVehicles<defaultMinPriceVehicle){
                console.log("calculatePriceTempHolidayPacket: Total price vehicles is less than minimum price vehicles");
                totalPriceVehicles= defaultMinPriceVehicle;
            }
            console.log("calculatePriceTempHolidayPacket: totalPrice: " + totalPriceVehicles);
            totalPrice = totalPrice + totalPriceVehicles;
        }       

        if(!Number.isInteger(totalPrice)){
            console.log("calculatePriceTempHolidayPacket: totalPrice is decimal");
            totalPrice = totalPrice.toFixed(1).toString().replace(".", ",");
        }else{
            console.log("calculatePriceTempHolidayPacket: totalPrice is not a decimal");
            totalPrice = totalPrice.toFixed(0).toString();
        }

        console.log("calculatePriceTempHolidayPacket: totalPrice: " + totalPrice);
        return totalPrice;
    };
};

module.exports = new TariffFunctions();