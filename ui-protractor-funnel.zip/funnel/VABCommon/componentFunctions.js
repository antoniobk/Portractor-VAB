var Common = require('./common.js');
var tariffFunctions = require('./tariffFunctions.js');

var ComponentFunctions = function(){
    var EC = protractor.ExpectedConditions;
    var common = new Common();
    
    this.fillAdditionalVehicles = function(additionalVehicles,totalVehicles,maxVehicles,totalTravelPrice,totalDays,totalMonths,totalPersons){
        console.log("ComponentFunctions: calculateAdditionalVehicles");
        console.log("calculateAdditionalVehicles: Bereken totaal voertuigen");
        totalAdditionalVehicles = additionalVehicles + totalVehicles;
        
        if (totalAdditionalVehicles<=maxVehicles && additionalVehicles > 0){
            console.log("calculateAdditionalVehicles: Voertuigen kunnen toegevoegd worden");            
            for(let i=totalVehicles; i< totalAdditionalVehicles;i++){
                element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[4]/li/div[2]/div/app-vehicles-option/div[2]/a')).click();
                browser.sleep(2000);

                this.fillVehicleInformation(i+1);        
                expectedPrice = tariffFunctions.calculatePriceTempHolidayPacket(totalTravelPrice,totalDays,totalMonths,totalPersons,i+1);
                
                var elementPrice = element(by.className("vab__calculator__form__price"));
                validatePrice = this.validatePrice(elementPrice,expectedPrice);
            }

        }else{
            console.log("calculateAdditionalVehicles: Er zijn meerdere/geen voertuigen dan toegelaten toegevoegd");
            additionalVehicles = 0;
        } 
    };

    this.fillAdditionalPersons = function(additionalPersons,totalPersons,maxPersons,totalTravelPrice,totalDays,totalMonths,totalVehicles){
        console.log("ComponentFunctions: calculateAdditionalPersons");
        totalAdditionalPersons = totalPersons + additionalPersons;

        if (totalAdditionalPersons<=maxPersons && additionalPersons > 0){
            console.log("calculateAdditionalPersons: Medereizigers kunnen toegevoegd worden");
            
            for(let i=totalPersons; i< totalAdditionalPersons;i++){
                element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div[2]/a/div')).click();
                browser.sleep(2000);

                this.fillPersonInformation(i+1);
                expectedPrice = tariffFunctions.calculatePriceTempHolidayPacket(totalTravelPrice,totalDays,totalMonths,i+1,totalVehicles);
                
                var elementPrice = element(by.className("vab__calculator__form__price"));
                validatePrice = this.validatePrice(elementPrice,expectedPrice);
            }

        }else{
            console.log("calculateAdditionalPersons: Er zijn meerdere/geen personen dan toegelaten toegevoegd");
            additionalPersons = 0;
        }
    };

    this.fillVehicleInformation = function(vehicleIndex){
        console.log("ComponentFunctions: fillVehicleInformation");
        console.log("fillVehicleInformation: Vul nummerplaat voertuig " + vehicleIndex + " in");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[4]/li/div[2]/div/app-vehicles-option/div[2]/app-vehicle['+ vehicleIndex +']/div/div/label/input')).sendKeys("kyq8941");
        // Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[1]/div/div/label[1]/input')).click();
        browser.sleep(2000);
    }

    this.fillPersonInformation = function(personIndex){   
        console.log("ComponentFunctions: fillPersonInformation");
        console.log("fillVehicleInformation: Vul persoon informatie " + personIndex + " in");
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person['+ personIndex +']/div/div/label[1]/input')).sendKeys(common.userFirstName + ' ' + personIndex);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person['+ personIndex +']/div/div/label[2]/input')).sendKeys(common.userLastName + ' ' +  personIndex);
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person['+ personIndex +']/div/div/label[3]/app-new-datepicker/div/input')).sendKeys(common.userBirthDate);
        
        // Wijzig focus door validaties
        element(by.xpath('//*[@id="page-container"]/app-product-funnel/div/form/div/div/div[1]/div/div/div/ul/app-collapsible-area[3]/li/div[2]/div/app-persons-option/div/div[2]/div/app-person[1]/div/div/label[1]/input')).click();
        browser.sleep(2000);
    };

    this.fillBehoefteAnalyse = function(){
        console.log("ComponentFunctions: fillBehoefteAnalyse");
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[3]/label[1]/span[2]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[4]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[5]/label[2]/span[1]')).click();
		browser.sleep(2000);
		element(by.xpath('/html/body/section[2]/div/div/div/div/div/div[1]/div/div/form/div/div/div[6]/label[1]/span[2]')).click();
		browser.sleep(2000);
    };

    this.fillPersonalData = function(){
        console.log("ComponentFunctions: fillAddress");
		common.zipcode.sendKeys(common.userZipcode);
		common.city.sendKeys(common.userCity);
		common.street.sendKeys(common.userStreet);
		common.houseNumber.sendKeys(common.userHouseNumber);
		common.email.sendKeys(common.userEmail);
    };

    this.addVehicle = function(){
        console.log("ComponentFunctions: addVehicle");
        element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[3]/div/div/div/label/div/app-plus-minus-input/div/div[3]/span')).click();
        browser.sleep(2000);       
    }

    this.addPerson = function(){
        console.log("ComponentFunctions: addPerson");
        var elementAddPersons=element(by.xpath('//*[@id="page-container"]/app-product-detail/section/div/div/app-product-detail-calculator/div/div/div/div/app-sticky-scroll-element/div/div/div/div[2]/div/div/div/div[1]/app-stepper-option/div/label/div[2]/app-plus-minus-input/div/div[3]/span'));
        elementAddPersons.click();

        browser.wait(EC.visibilityOf(elementAddPersons), 50000, "Timeout of VisibilityOf: Tijdelijk vakantiepakket");
        browser.sleep(4000);
                 
    }
    
    
    this.validatePrice = function (elementPrice,expectedPrice){
		console.log("TariffFunctions: validatePrice");
        elementPrice.getText().then(function (actualPrice) {            
			console.log('validatePrice: Actual price = ' + actualPrice + ' Expected price = ' + expectedPrice);
            expect(actualPrice).toBe('€ ' + expectedPrice);
		});
    }
};

module.exports = new ComponentFunctions();