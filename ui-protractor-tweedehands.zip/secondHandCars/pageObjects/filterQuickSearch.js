var filterQuickSearch = function () {
    var dropdownBrand = element(by.xpath("/html/body/app-root/div/app-quick-search/section/div/div[1]/div/div[1]/div/app-dropdown/label/span[2]/select"));
    var dropdownModel = element(by.xpath("/html/body/app-root/div/app-quick-search/section/div/div[1]/div/div[2]/div/app-dropdown/label/span[2]/select"));
    var dropdownPrice = element(by.xpath("/html/body/app-root/div/app-quick-search/section/div/div[1]/div/div[3]/div/app-dropdown/label/span[2]/select"));
    var fifthBrandInDropdown = element(by.xpath("//option[@value = '5: 2834--dacia']"));
    var firstModelInDropdown = element(by.xpath("//option[contains(text(),'Dokker')]"));
    var firstPriceInDropdown = element(by.xpath("//option[@value = '1: 10001-14999--10001-14999']"));
    var btnShowSelection = element(by.xpath("//a[@class='button button--fluid']"));
    var resultAmount = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/header/h3/span"));
    var priceLabelPosition = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div/a/article/div/span[2]/span[2]/span[1]"));
    var priceLabel = element(by.xpath("//span[@class='carTeaser__price'][contains(text(),'Verkocht')]"));
    var resultGlobal = "";

    var checkBoxCarBrand = element(by.xpath("/html/body/app-root/div/app-overview/section/div/aside/app-filter/section/div/div[1]/div[2]/div/div[5]/div/app-checkbox/div/label/span[1]/input"));
    var checkboxCarModel = element(by.xpath("/html/body/app-root/div/app-overview/section/div/aside/app-filter/section/div/div[2]/div[2]/div/div/div/app-checkbox/div/label/span[1]/input"));
    var checkBoxPrice = element(by.xpath("/html/body/app-root/div/app-overview/section/div/aside/app-filter/section/div/div[3]/div[2]/div/div[2]/div/app-checkbox/div/label/span[1]/input"));

    this.quickSearchCar = function () {
        console.log("FilterQuickSearch: Selecting a car using the quick search");
        dropdownBrand.click();
        browser.sleep(1000);
        fifthBrandInDropdown.click();
        browser.sleep(1000);
        dropdownModel.click();
        browser.sleep(1000);
        firstModelInDropdown.click();
        browser.sleep(1000);
        dropdownPrice.click();
        browser.sleep(1000);
        //firstPriceInDropdown.click();
        //browser.sleep(1000);
        btnShowSelection.click();
        browser.sleep(5000);
    }
    this.getResultAmount = function () {
        resultAmount.getText().then(function (RS) {
            expect(RS).toBeGreaterThan(0);
            console.log("FilterQuickSearch: Total of result: " + RS);
            resultGlobal = RS
        });
    }
    this.verifyCheckBoxSelected = function () {
        console.log("FilterQuickSearch: Verifying if car brand checkbox is selected..");
        expect(checkBoxCarBrand.isSelected()).toBe(true);
        console.log("FilterQuickSearch: Car model checkbox is selected");

        console.log("FilterQuickSearch: Verifying if car model checkbox is selected..")
        expect(checkboxCarModel.isSelected()).toBe(true);

        console.log("FilterQuickSearch: Verifying if price checkbox is selected..");
        expect(checkBoxPrice.isSelected()).toBe(true);
    }
    this.validateCarSold = function () {
        priceLabelPosition.getText().then(function (PL) {

            if (resultGlobal == 1 && PL == "Verkocht") {
                console.log("FilterQuickSearch: There is Only one car and the car is sold, stopping test.");
                process.exit();
            }
            else {
                console.log("FilterQuickSearch: Car is not sold, car price is: " + PL + "Clicking on first car..")
                priceLabelPosition.click();
            }
        });
    }
};
module.exports = new filterQuickSearch();