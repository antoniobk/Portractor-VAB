var Product = function () {
    var banner = element(by.xpath("//h3[contains(text(),'Verkocht')]"));
    var BN = "";
    var firstCar = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/span[2]/span[1]"));
    var secondCar = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[2]/a/article/div/span[1]/span[1]"));
    var carName = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/div"));
    var carNameDetail = element(by.xpath("//h1[@id='model_title']"));
    var fuel = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/span[1]/span[1]/span[2]"));
    var constructionYear = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/span[1]/span[2]/span[2]"));
    var kilometerStand = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/span[1]/span[3]/span[2]"));
    var transmission = element(by.xpath("/html/body/app-root/div/app-overview/section/div/main/app-product-list/section/div/app-product-item/div[1]/a/article/div/span[2]/span[1]/span[4]/span[2]"));
    var fuelDetail = element(by.xpath("/html/body/div[2]/div/aside/div[1]/section[1]/ul/li[1]/span[2]"));
    var constructionYearDetail = element(by.xpath("/html/body/div[2]/div/aside/div[1]/section[1]/ul/li[2]/span[2]"));
    var mileageDetail = element(by.xpath("/html/body/div[2]/div/aside/div[1]/section[1]/ul/li[3]/span[2]"));
    var transmissionDetail = element(by.xpath("/html/body/div[2]/div/aside/div[1]/section[1]/ul/li[4]/span[2]"));
    var CNGlobal = "";
    var FTGlobal = "";
    var CYGlobal = "";
    var MLGlobal = "";
    var TTGlobal = "";
    var btnFinancialSection = element(by.xpath("//h3[@onclick='financeClass.init()']"));
    var controlPriceLeft = element(by.id("AdvanceMinLabel"));
    var controlPriceRight = element(by.id("AdvanceMaxLabel"));
    var referencePrice = element(by.xpath("//output[@class='input__flag']"));
    var referencePriceGlobal = "";
    var period = element(by.id("Period"));
    var periodGlobal = "";
    var jkp = element(by.id("jkp"));
    var jkpGlobal = "";
    var CPRGLOBAL = "";
    var CPLGlobal = "";
    var sliderBar = element(by.xpath("//input[@type='range']"));
    var checkboxResidualValue = element(by.xpath("/html/body/div[2]/div/aside/div[1]/section[2]/div/div/div/div[2]/label/span[1]/span"));
    var monthlyPaymentWithResidualValue = element(by.xpath("/html/body/div[2]/div/aside/div[1]/section[2]/div/div/footer/div[1]/span"));
    //same variable just for a better overview in different function
    var monthlyPaymentWithoutResidualValue = element(by.xpath("/html/body/div[2]/div/aside/div[1]/section[2]/div/div/footer/div[1]/span"));
    var monthlyPaymentWithResidualValueGlobal = "";

    this.getCarName = function () {
        carName.getText().then(function (CN) {
            console.log("Product: Carname: " + CN);
            CNGlobal = CN;
            return CNGlobal;
        });
    }
    this.getFuelType = function () {
        fuel.getText().then(function (FT) {
            console.log("Product: Fuel type: " + FT);
            FTGlobal = FT;
            return FTGlobal;
        });
    }
    this.getConstructionYear = function () {
        constructionYear.getText().then(function (CY) {
            console.log("Product: Construction Year: " + CY);
            CYGlobal = CY;
            return CYGlobal;
        });
    }
    this.getMileage = function () {
        kilometerStand.getText().then(function (ML) {
            console.log("Product: Mileage: " + ML);
            MLGlobal = ML;
            return MLGlobal;
        });
    }
    this.getTransmission = function () {
        transmission.getText().then(function (TT) {
            console.log("Product: Transmission: " + TT);
            TTGlobal = TT;
            return TTGlobal;
        });
    }

    this.verifyCarSold = function () {
        banner.getText().then(function (BNR) {
            if (BNR == "Verkocht") {
                console.log("Car is sold, stopping test");
                process.exit();
            }

            else {
                console.log("Continuing test")
               
            }
            BN = BNR;
            return HN;
        });
    }
   

    this.clickOnFirstCar = function () {
        firstCar.click();
        browser.sleep(8000);
    }
  
    this.validateCarNameDetail = function () {
        browser.waitForAngularEnabled(false);
        carNameDetail.getText().then(function (CDP) {
            console.log("Product: Car name expected value: " + CNGlobal + ", actual value: " + CDP);
            expect(CNGlobal).toContain(CDP);
            console.log("Product: Car name on detail page: " + CDP);
        });
    }
    this.validateFuelDetail = function () {
        fuelDetail.getText().then(function (FDP) {
            console.log("Product: Car name expected value: " + FTGlobal + ", actual value: " + FDP)
            expect(FDP).toBe(FTGlobal);
            console.log("Product: Fuel on detail page: " + FDP);
        });
    }
    this.validateConstructionYearDetail = function () {
        constructionYearDetail.getText().then(function (CYD) {
            removeMonth = CYD.slice(5);
            console.log("Product: Car name expected value: " + CYGlobal + ", actual value: " + removeMonth);
            expect(removeMonth).toBe(CYGlobal);
            console.log("Product: Constrution year on detail page is: " + removeMonth);
        });
    }
    this.validateMileageDetail = function () {
        mileageDetail.getText().then(function (MDP) {
            console.log("Product: Car name expected value: " + MLGlobal + ", actual value: " + MDP);
            expect(MDP).toBe(MLGlobal);
            console.log("Product: Mileage on detail page is: " + MDP);
        });
    }
    this.validateTansmissionDetail = function () {
        transmissionDetail.getText().then(function (TDP) {
            console.log("Product: Car name expected value: " + TTGlobal + ", actual value: " + TDP);
            expect(TDP).toBe(TTGlobal);
            console.log('Product: Getting transmission type on detail page: ' + TDP);
        });

    }

    this.openFinancialSection = function () {
        btnFinancialSection.click();
        browser.sleep(1000);
    }

    this.getReferencePrice = function () {
        referencePrice.getText().then(function (RP) {
            console.log("Product: " + "Reference price: " + RP);
            referencePriceGlobal = RP;
            referencePriceGlobalInt = parseInt(referencePriceGlobal)
        });
    }

    this.getPriceLeft = function () {
        controlPriceLeft.getText().then(function (CPL) {
            console.log("Product: Price left: " + CPL);
            CPLGlobal = CPL;
            expect(CPL).toBeLessThan(referencePriceGlobal)

        });
    }

    this.getPriceRight = function () {
        controlPriceRight.getText().then(function (CPR) {
            console.log("Product: Price right: " + CPR);
            CPRGLOBAL = CPR;
            expect(CPR).toBeGreaterThan(referencePriceGlobalInt);
        });
    }

    this.getPeriod = function () {
        period.getText().then(function (P) {
            console.log("Product: Current period: " + P + " months");
            periodGlobal = P;
        });

    }

    this.getJkp = function () {
        jkp.getText().then(function (JKP) {
            console.log("Product: Current JKP: " + JKP + " %");
            jkpGlobal = JKP;
        });
    }

    //Not working as it should
    this.slideRight = function () {
        browser.actions().dragAndDrop(sliderBar, { x: 200, y: 0 }).perform()
        browser.sleep(3000);

    }
    //Not working as it should
    this.slideLeft = function () {
        browser.actions().dragAndDrop(sliderBar, { x: -300, y: 0 }).perform()
        browser.sleep(3000)
    }

    this.getMonthlyPaymentWithResidualValue = function () {
        monthlyPaymentWithResidualValue.getText().then(function (MPWRV) {
            console.log("Product: Getting monthly payment that includes residual value, " + "Value: " + MPWRV);
            monthlyPaymentWithResidualValueGlobal = MPWRV
        });
    }
    this.deselectResidualValue = function () {
        checkboxResidualValue.click();
    }

    this.getMonthlyPaymentWithoutResidualValue = function () {
        monthlyPaymentWithoutResidualValue.getText().then(function (MPWRV2) {
            console.log("Product: Getting monthly payment that doesn't include residual value, " + "Value: " + MPWRV2);
            console.log("Product: Validating that monthly payment is higher when residual value is deselected, monthly payment before: " + monthlyPaymentWithResidualValueGlobal + ", current monthly payment: " + MPWRV2)
            expect(MPWRV2).toBeGreaterThan(monthlyPaymentWithResidualValueGlobal);
        });
    }

    this.validatePeriod = function () {
        period.getText().then(function (P2) {
            console.log("Product: Period after change " + P2 + " months");
            expect(P2).toEqual(periodGlobal);
        });

    }

    this.validateJkp = function () {
        jkp.getText().then(function (JKP2) {
            console.log("Product: JKP after change: " + JKP2 + " %");
            expect(JKP2).toEqual(jkpGlobal);
        });
    }

}
module.exports = new Product(); 
