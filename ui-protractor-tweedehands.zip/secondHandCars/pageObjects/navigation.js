var Navigation = function () {
    var btnVolledigAanbod = element(by.xpath("//a[@class='button button--fluid']"));
    var acceptCookieBtn = element(by.xpath("/html/body/div/div[2]/div[4]/a[2]"));
    var EC = protractor.ExpectedConditions;

    this.get = function () {
		console.log("Navigation: get");
        browser.get("https://acc.vab.be/nl/auto/tweedehandswagens");
        browser.wait(EC.visibilityOf(btnVolledigAanbod), 30000, "Timeout of VisibilityOf: Homepage secondhandcars");
        browser.sleep(5000);
    };

    this.acceptCookies = function () {
		console.log("Navigation: acceptCookies");
        acceptCookieBtn.click();
        browser.sleep(5000);
    };

    this.bekijkVolledigAanbod = function () {
		console.log("Navigation: bekijkVolledigAanbod");
        btnVolledigAanbod.click();
        browser.sleep(5000);
    };
};
module.exports = new Navigation();