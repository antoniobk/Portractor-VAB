var filterCategorySearch = function () {

    var btnAutomaat = element(by.xpath("//span[@class='categorySearch__label'][contains(text(),'Automaat')]"));
    var carFilterResultAmount = element(by.xpath("//span[@class='carFilterResult__amount']"));
    var selectedCheckbox = element(by.xpath("/html/body/app-root/div/app-overview/section/div/aside/app-filter/section/div/div[4]/div[2]/div/div[1]/div/app-checkbox/div/label/span[1]/input"));


    this.clickOnCategory = function () {
        btnAutomaat.click();
        browser.sleep(5000);
    }
    this.validateResultsBiggerThanZero = function () {
        browser.waitForAngularEnabled(false);
        carFilterResultAmount.getText().then(function (totalResult) {
            console.log("FilterCategorySearch: expected total results: " + " >=1" + ", actual value: " + totalResult);
            expect(totalResult).toBeGreaterThan(0);

            if (totalResult >= 1) {
                console.log("FilterCategorySearch: results OK, continuing test.. ");
            }
            else {
                console.log("FilterCategorySearch: No results, stopping test.");
                process.exit();
            }
        });
    }

    this.validateCheckBoxSelected = function () {
        console.log("FilterCategorySearch: Verifying if checkbox is selected..");
        expect(selectedCheckbox.isSelected()).toBe(true);
    }

}
module.exports = new filterCategorySearch();