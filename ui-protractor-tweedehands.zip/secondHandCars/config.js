//var jasmineReporters = require('./jasmine-reporters');
//var reportsDirectory = 'funnel/reports';

exports.config = {
  
    framework: 'jasmine',
    seleniumAddress: 'http://localhost:4444/wd/hub',
    getPageTimeout: 22000,
    
    jasmineNodeOpts: {
      defaultTimeoutInterval: 50000
      
    },
    capabilities: {
      
      browserName: 'chrome',    
      shardTestFiles: true,
      maxInstances: 1,
      
    },  
    specs: ['specs/secondHandCars.js','specs/secondHandCarsQuickSearch.js','specs/secondHandCarsCategorySearch.js'], 

    onPrepare: function () {
        //Maximize
        browser.driver.manage().window().maximize();
  
       /* //xml report generated for Azure DevOps
        jasmine.getEnv().addReporter(new jasmineReporters.JUnitXmlReporter({
            consolidateAll: false,
            savePath: reportsDirectory + '/xml',
            filePrefix: 'xmlOutput'
        }));*/
      
    } 
  };