var navigation = require('../pageObjects/navigation.js');
var product = require('../pageObjects/product.js');


describe('SecondHandCars: Navigating', function () {
	it('SecondHandCars: Open browser, navigate to homepage', function () {
		console.log("SecondHandCars: Navigeren naar tweedehands pagina..");
		navigation.get();
	});

	it('SecondHandCars: Accepting cookies', function () {
		console.log("SecondHandCars: Accepting cookies..");
		navigation.acceptCookies();
	})

	it('SecondHandCars: Navigeren naar volledig aanbod', function () {
		console.log("SecondHandCars: Klikken op: 'Bekijk volledig aanbod'..");
		navigation.bekijkVolledigAanbod();
	});


	it('SecondHandCars: Getting car name', function () {
		console.log("SecondHandCars: Getting car name..");
		product.getCarName();
	});

	it('SecondHandCars: Getting fuel type', function () {
		console.log("SecondHandCars: Getting fuel type..");
		product.getFuelType();
	});

	it('SecondHandCars: Getting construction year', function () {
		console.log("SecondHandCars: Getting construction year..");
		product.getConstructionYear();
	});

	it('SecondHandCars: Getting mileage', function () {
		console.log("SecondHandCars: Getting mileage..");
		product.getMileage();
	});

	it('SecondHandCars: Getting transmission type', function () {
		console.log("SecondHandCars: Getting transmission type..");
		product.getTransmission();
	});

	it('SecondHandCars: Clicking on car', function () {
		console.log("SecondHandCars: Clicking on car car..");
		product.clickOnFirstCar();
	});

	it('SecondHandCars: Getting car name on detail page', function () {
		console.log("SecondHandCars: Getting car name on detail page..");
		product.validateCarNameDetail();
	});

	it('SecondHandCars: Getting fuel type on detail page', function () {
		console.log("SecondHandCars: Getting fuel type on detail page..");
		product.validateFuelDetail();
	});

	it('SecondHandCars: Getting construction year on detail page ', function () {
		console.log("SecondHandCars: Getting construction year on detail page..");
		product.validateConstructionYearDetail();
	});

	it('SecondHandCars: Getting mileage on detail page', function () {
		console.log("SecondHandCars: Getting mileage on detail page..");
		product.validateMileageDetail();
	});

	it('SecondHandCars: Getting transmission type op detail page', function () {
		console.log("SecondHandCars: Getting transmission type on detail page..");
		product.validateTansmissionDetail();
	});

	it('SecondHandCars: Verifying if car is sold', function() {
		console.log("SecondHandCars: Verifying if car is sold..")
		product.verifyCarSold();
	})

	it('SecondHandCars: Opening financial section', function() {
		console.log("SecondHandCars: Opening financial section..");
		product.openFinancialSection();
	});

	it('SecondHandCars: Getting reference price', function() {
		console.log("SecondHandCars: Getting reference price..");
		product.getReferencePrice();
	});

	it('SecondHandCars: Get price left', function() {
		console.log("SecondHandCars: Getting control price left..");
		product.getPriceLeft();
	});
	it('SecondHandCars: Get price right', function() {
		console.log("SecondHandCars: Getting control price right..");
		product.getPriceRight();
	});

	it('SecondHandCars: Getting period in months', function() {
		console.log("SecondHandCars: Getting period in months")
		product.getPeriod();
	});

	it('SecondHandCars: Getting JKP', function() {
		console.log("SecondHandCars: Getting JKP")
		product.getJkp();
	});

	it('SecondHandCars: Sliding bar to right side', function(){
		console.log("SecondHandCars: Sliding bar to right side")
		product.slideRight();
	});

	it('SecondHandCars: Sliding bar to left side', function(){
		console.log("SecondHandCars: Sliding bar to left side")
		product.slideLeft();
	});

	it('SecondHandCars: Validating that period is still the same', function(){
		console.log("SecondHandCars: Validating that period is still the same");
		product.validatePeriod();
	});
	
	it('SecondHandCars: Validating that JKP is still the same', function() {
		console.log("SeoncHandCars: Validating that JKP is still the same");
		product.validateJkp();
	});

	
	it('SecondHandCars: Getting monthly payment with residual value', function() {
		console.log("SecondHandCars: Getting monthly payment with residual value");
		product.getMonthlyPaymentWithResidualValue();
	});

	it('SecondHandCars: Deselecting residual value checkbox', function(){
		console.log("SecondHandCars: Deselecting residual value checkbox");
		product.deselectResidualValue();
	});
	
	it('SecondHandCars: Getting monthly payment without residual value', function() {
		console.log("SecondHandCars: Getting monthly paymend without residual value")
		product.getMonthlyPaymentWithoutResidualValue();
	});

	
});

